local rules = {}

local config = require("horn_resonance/core/config")

local parsed_blocked = nil
local parsed_override = nil
local cached_blocked = nil
local cached_override = nil

local function split(s, sep)
    local out = {}
    local pos = 1
    while true do
        local i = string.find(s, sep, pos, true)
        if not i then
            local tail = string.sub(s, pos)
            if tail ~= "" then table.insert(out, tail) end
            break
        end
        local piece = string.sub(s, pos, i - 1)
        if piece ~= "" then table.insert(out, piece) end
        pos = i + #sep
    end
    return out
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function enabled()
    return config.get("l2_override_enabled") ~= false
end

local function ensure()
    local b = tostring(config.get("l2_blocked_actions") or "")
    if b ~= cached_blocked then
        cached_blocked = b
        parsed_blocked = {}
        local names = {}
        for _, tok in ipairs(split(b, ",")) do
            local n = tonumber(trim(tok))
            if n and n > 0 then
                parsed_blocked[math.floor(n)] = true
                table.insert(names, tostring(math.floor(n)))
            end
        end
        log.info("[HornResonance/rules] 禁止 ZL 取消的動作：" ..
            (#names > 0 and table.concat(names, ", ") or "（無）"))
    end

    local o = tostring(config.get("l2_override_frames") or "")
    if o ~= cached_override then
        cached_override = o
        parsed_override = {}
        local names = {}
        for _, tok in ipairs(split(o, ",")) do
            local a, f = string.match(trim(tok), "^(%d+)%s*[:=]%s*(%d+%.?%d*)$")
            if a and f then
                local action = math.floor(tonumber(a))
                local frame = tonumber(f)
                if action > 0 and frame and frame >= 0 then
                    parsed_override[action] = frame
                    table.insert(names, string.format("%d=%.0f", action, frame))
                end
            end
        end
        log.info("[HornResonance/rules] 手動取消點：" ..
            (#names > 0 and table.concat(names, ", ") or "（無）"))
    end
end

function rules.is_blocked(action)
    if not enabled() then return false end
    ensure()
    local a = math.floor(action or 0)
    if a <= 0 then return false end
    return parsed_blocked[a] == true
end

function rules.get_override(action)
    if not enabled() then return nil end
    ensure()
    local a = math.floor(action or 0)
    if a <= 0 then return nil end
    return parsed_override[a]
end

function rules.summary()
    if not enabled() then return "手動規則：已關閉" end
    ensure()
    local blocked, overrides = {}, {}
    for a in pairs(parsed_blocked or {}) do table.insert(blocked, tostring(a)) end
    for a, f in pairs(parsed_override or {}) do
        table.insert(overrides, string.format("%d=%.0f", a, f))
    end
    table.sort(blocked)
    table.sort(overrides)
    return string.format("禁止：%s ｜ 手動取消點：%s",
        #blocked > 0 and table.concat(blocked, ",") or "無",
        #overrides > 0 and table.concat(overrides, ",") or "無")
end

function rules.reset_cache()
    cached_blocked = nil
    cached_override = nil
    parsed_blocked = nil
    parsed_override = nil
end

return rules
