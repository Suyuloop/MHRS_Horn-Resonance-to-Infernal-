local evade_cancel = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")
local pad = require("horn_resonance/core/pad")

local sticky_left = 0
local sticky_node = 0
local skip_sticky = false
local last_trigger = -1000.0
local trigger_cooldown = 0.4

local stats = {
    triggers = 0,
    early_triggers = 0,
    too_early = 0,
    blocked = 0,
    fail = 0,
    wrong_bank = 0,
    hit_blocked = 0,
    last_frame = -1,
    last_dir = "—",
    by_dir = { front = 0, left = 0, right = 0, back = 0 },
    last_reason = "—",
}

local NODE_KEYS = {
    front = "evade_cancel_node",
    left  = "evade_cancel_node_left",
    right = "evade_cancel_node_right",
    back  = "evade_cancel_node_back",
}

local DIR_NAME = {
    front = "往前",
    left  = "往左",
    right = "往右",
    back  = "往後",
}

local function pick_node(dir)
    local key = NODE_KEYS[dir] or "evade_cancel_node"
    local n = config.get(key)
    if not n or n == 0 then n = config.get("evade_cancel_node") end
    return math.floor(n or 0)
end

local function current_dir()
    if config.get("evade_cancel_direction") == false then return "front" end
    return pad.stick_dir()
end

local function in_infernal()
    local node = game.get_current_node()
    local target = config.get("infernal_node")
    if not node or node == 0 then return false end
    if not target or target == 0 then return false end
    return node == target
end

function evade_cancel.update()
    local now = game.time()

    if config.get("evade_cancel_enabled") == false then
        sticky_left = 0
        skip_sticky = false
        return
    end

    if sticky_left > 0 and not skip_sticky then

        if not game.is_weapon_action() then
            sticky_left = 0
        else
            local esc = sticky_node
            if esc == 0 then esc = pick_node("front") end
            local node = game.get_current_node()
            if node == esc then
                sticky_left = 0
            else
                game.set_current_node(esc)
                sticky_left = sticky_left - 1
            end
        end
    end
    skip_sticky = false

    if not game.is_horn() or not game.is_ready() then return end

    if not in_infernal() then return end

    if not game.is_weapon_action() then
        stats.wrong_bank = stats.wrong_bank + 1
        stats.last_reason = string.format("非武器動作（bank %d），不搶 B 鍵", game.get_bank_id())
        return
    end

    local grace = config.get("hit_grace") or 1.2
    if game.time_since_hit() < grace then
        stats.hit_blocked = stats.hit_blocked + 1
        stats.last_reason = string.format("剛受擊（%.2f 秒前），讓給翔蟲受身",
            game.time_since_hit())
        return
    end

    local st = pad.state()
    if not st.ok or not st.b_trg then return end

    local frame = game.get_motion_frame()
    if type(frame) ~= "number" then return end
    stats.last_frame = frame

    local need = config.get("evade_cancel_frame") or 115
    local early = config.get("evade_cancel_early_frames") or 50
    local early_min = config.get("evade_cancel_early_min") or 30
    local early_on = config.get("evade_cancel_early_enabled") ~= false
    if early_min > early then early_min = early end

    local kind = nil
    if early_on and frame >= early_min and frame <= early then
        kind = "early"
    elseif frame >= need then
        kind = "late"
    end

    if not kind then
        stats.too_early = stats.too_early + 1
        stats.last_reason = string.format("等 buff（幀 %.0f，可取消 %.0f~%.0f 或 %.0f 之後）",
            frame, early_min, early, need)
        return
    end

    if (now - last_trigger) < trigger_cooldown then
        stats.blocked = stats.blocked + 1
        stats.last_reason = "冷卻中"
        return
    end

    local dir = current_dir()

    local esc = pick_node(dir)
    if esc == 0 then
        stats.last_reason = "翻滾節點未設定"
        return
    end
    if game.set_current_node(esc) then
        sticky_left = math.floor(config.get("evade_cancel_sticky") or 6)
        sticky_node = esc
        skip_sticky = true
        last_trigger = now
        stats.last_dir = dir
        stats.by_dir[dir] = (stats.by_dir[dir] or 0) + 1
        local dir_cn = DIR_NAME[dir] or dir
        if kind == "early" then
            stats.early_triggers = stats.early_triggers + 1
            stats.last_reason = string.format("緊急迴避（%s，幀 %.0f）", dir_cn, frame)
            log.info(string.format(
                "[HornResonance/evade_cancel] 緊急迴避氣焰旋律：%s（動作幀 %.0f，窗口 %.0f~%.0f）→ 0x%08X",
                dir_cn, frame, early_min, early, esc))
        else
            stats.triggers = stats.triggers + 1
            stats.last_reason = string.format("取消後搖（%s，幀 %.0f）", dir_cn, frame)
            log.info(string.format(
                "[HornResonance/evade_cancel] 翻滾取消氣焰旋律：%s（動作幀 %.0f，門檻 %.0f）→ 0x%08X",
                dir_cn, frame, need, esc))
        end
    else
        stats.fail = stats.fail + 1
        stats.last_reason = "setCurrentNode 失敗"
        log.warn("[HornResonance/evade_cancel] setCurrentNode 失敗（行為樹尚未取得？）")
    end
end

function evade_cancel.get_stats()
    return stats
end

function evade_cancel.get_info()
    local bits = pad.dir_bits()
    return {
        triggers = stats.triggers,
        early_triggers = stats.early_triggers,
        too_early = stats.too_early,
        blocked = stats.blocked,
        fail = stats.fail,
        wrong_bank = stats.wrong_bank,
        hit_blocked = stats.hit_blocked,
        last_frame = stats.last_frame,
        last_reason = stats.last_reason,
        in_infernal = in_infernal(),
        frame = game.get_motion_frame(),
        need = config.get("evade_cancel_frame") or 115,
        early = config.get("evade_cancel_early_frames") or 50,
        early_min = config.get("evade_cancel_early_min") or 30,
        early_enabled = config.get("evade_cancel_early_enabled") ~= false,
        sticky_left = sticky_left,
        is_weapon_action = game.is_weapon_action(),
        bank = game.get_bank_id(),
        since_hit = game.time_since_hit(),

        last_dir = stats.last_dir,
        by_dir = stats.by_dir,
        dir = current_dir(),
        dir_bits = bits,
        has_dir = pad.dir() ~= nil,
        direction_enabled = config.get("evade_cancel_direction") ~= false,
    }
end

function evade_cancel.reset()
    sticky_left = 0
    sticky_node = 0
    skip_sticky = false
    last_trigger = -1000.0
    stats.last_frame = -1
    stats.last_dir = "—"
    stats.by_dir = { front = 0, left = 0, right = 0, back = 0 }
    stats.last_reason = "—"
end

function evade_cancel.dump()
    local info = evade_cancel.get_info()
    log.info("──────── HornResonance 翻滾取消 ────────")
    log.info("  啟用           : " .. tostring(config.get("evade_cancel_enabled")))
    log.info("  緊急迴避窗口   : " .. (info.early_enabled
        and string.format("%d ~ %d 幀", info.early_min, info.early) or "關閉"))
    log.info("  取消後搖門檻   : " .. tostring(info.need) .. " 幀（動作幀）")
    log.info(string.format("  翻滾節點       : 前 0x%08X ／ 左 0x%08X ／ 右 0x%08X ／ 後 0x%08X",
        config.get("evade_cancel_node") or 0,
        config.get("evade_cancel_node_left") or 0,
        config.get("evade_cancel_node_right") or 0,
        config.get("evade_cancel_node_back") or 0))
    log.info(string.format("  方向感知       : %s", tostring(info.direction_enabled)))
    log.info(string.format("  左搖桿方向     : 前%s 後%s 左%s 右%s → %s",
        info.dir_bits.front and "●" or "○",
        info.dir_bits.back and "●" or "○",
        info.dir_bits.left and "●" or "○",
        info.dir_bits.right and "●" or "○",
        DIR_NAME[info.dir] or tostring(info.dir)))
    log.info("  黏著幀數       : " .. tostring(config.get("evade_cancel_sticky")))
    log.info("  目前在氣焰旋律 : " .. tostring(info.in_infernal))
    log.info(string.format("  目前動作幀     : %.1f", info.frame or 0.0))
    log.info("  武器動作中     : " .. tostring(info.is_weapon_action)
        .. string.format("（bank %d）", info.bank or 0))
    log.info(string.format("  距上次受擊     : %.2f 秒", info.since_hit or 0.0))
    log.info("  取消後搖       : " .. info.triggers)
    log.info("  緊急迴避       : " .. info.early_triggers)
    log.info(string.format("  方向統計       : 前 %d ／ 左 %d ／ 右 %d ／ 後 %d（最後一次：%s）",
        info.by_dir.front or 0, info.by_dir.left or 0,
        info.by_dir.right or 0, info.by_dir.back or 0,
        DIR_NAME[info.last_dir] or tostring(info.last_dir)))
    log.info("  等 buff 禁區   : " .. info.too_early)
    log.info("  冷卻擋掉       : " .. info.blocked)
    log.info("  非武器動作讓鍵 : " .. info.wrong_bank .. " 次（受身 / 倒地時不搶 B）")
    log.info("  受擊後讓鍵     : " .. info.hit_blocked .. " 次（讓給翔蟲受身）")
    log.info("  切換失敗       : " .. info.fail)
    log.info("  最後按 B 的幀  : " .. string.format("%.1f", info.last_frame))
    log.info("  最近結果       : " .. info.last_reason)
    log.info("─────────────────────────────────────")
end

return evade_cancel
