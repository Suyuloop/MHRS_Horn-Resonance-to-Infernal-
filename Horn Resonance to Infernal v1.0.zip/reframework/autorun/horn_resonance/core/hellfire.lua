local hellfire = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")

local TD_PQB = "snow.player.PlayerQuestBase"
local TD_CHAR = "snow.CharacterBase"
local TD_VEC3 = "via.vec3"

local resolve_state = 0

local m_state
local m_damage
local m_shell
local m_clear
local m_pos
local vec3_td

local function split(s, sep)
    local out = {}
    local pos = 1
    while true do
        local i = string.find(s, sep, pos, true)
        if not i then
            local tail = string.sub(s, pos)
            if tail ~= "" then table.insert(out, tail) end
            break
        end
        local piece = string.sub(s, pos, i - 1)
        if piece ~= "" then table.insert(out, piece) end
        pos = i + #sep
    end
    return out
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local cached_actions, parsed_actions = nil, nil

local function ensure_list()
    local raw = tostring(config.get("hellfire_shake_actions") or "")
    if raw ~= cached_actions then
        cached_actions = raw
        parsed_actions = {}
        local names = {}
        for _, tok in ipairs(split(raw, ",")) do
            local n = tonumber(trim(tok))
            if n and n > 0 then
                parsed_actions[math.floor(n)] = true
                table.insert(names, tostring(math.floor(n)))
            end
        end
        log.info("[HornResonance/hellfire] 甩鬼火的動作：" ..
            (#names > 0 and table.concat(names, ", ") or "（無）"))
    end
    return parsed_actions
end

local function is_target(action)
    local a = math.floor(action or 0)
    if a <= 0 then return false end
    local set = ensure_list()
    return set ~= nil and set[a] == true
end

local function need_frame()
    local n = math.floor(config.get("hellfire_shake_frame") or 10)
    if n < 0 then n = 0 end
    return n
end

local function find_method(td, name)
    local ok, m = pcall(td.get_method, td, name)
    if ok and m then return m end

    local ok_list, methods = pcall(td.get_methods, td)
    if not ok_list or not methods then return nil end
    for _, m2 in ipairs(methods) do
        local ok_n, n = pcall(function() return m2:get_name() end)
        if ok_n and n == name then return m2 end
    end
    return nil
end

local function resolve()
    if resolve_state ~= 0 then return resolve_state == 1 end
    resolve_state = -1

    local ok_td, td = pcall(sdk.find_type_definition, TD_PQB)
    if not ok_td or not td then
        log.warn("[HornResonance/hellfire] 找不到型別 " .. TD_PQB .. "，甩鬼火功能停用")
        return false
    end

    m_state = find_method(td, "isOniBombDamageState")
    m_damage = find_method(td, "isOniBombDamage")
    m_shell = find_method(td, "setOniBombShell")
    m_clear = find_method(td, "clearOniBombDamage")

    if (not m_state and not m_damage) or not m_shell or not m_clear then
        log.warn(string.format(
            "[HornResonance/hellfire] 鬼火 API 不完整（state=%s damage=%s shell=%s clear=%s），功能停用",
            tostring(m_state ~= nil), tostring(m_damage ~= nil),
            tostring(m_shell ~= nil), tostring(m_clear ~= nil)))
        return false
    end

    local ok_ct, ctd = pcall(sdk.find_type_definition, TD_CHAR)
    if ok_ct and ctd then
        m_pos = find_method(ctd, "get_Pos")
    end
    if not m_pos then
        log.warn("[HornResonance/hellfire] 讀不到 get_Pos，甩鬼火功能停用（避免把鬼火丟在座標 0,0,0）")
        return false
    end

    local ok_v, vtd = pcall(sdk.find_type_definition, TD_VEC3)
    if ok_v then vec3_td = vtd end

    resolve_state = 1
    log.info("[HornResonance/hellfire] 鬼火 API 就緒（setOniBombShell / clearOniBombDamage）")
    return true
end

local function make_vec3(src)
    if not vec3_td then return src end
    if type(ValueType) ~= "table" or type(ValueType.new) ~= "function" then return src end

    local ok, out = pcall(function()
        local v = ValueType.new(vec3_td)
        v:set_field("x", src:get_field("x"))
        v:set_field("y", src:get_field("y"))
        v:set_field("z", src:get_field("z"))
        return v
    end)
    if ok and out then return out end
    return src
end

local function read_pos(obj)
    if not m_pos then return nil end
    local ok, v = pcall(function() return m_pos:call(obj) end)
    if ok and v then return v end
    return nil
end

local has_hellfire = false
local last_action = -1
local done_action = -1

local stats = {
    shakes = 0,
    no_debuff = 0,
    pos_fail = 0,
    fail = 0,
    last_reason = "—",
}

function hellfire.has_hellfire()
    return has_hellfire
end

function hellfire.check_state()
    if not resolve() then return nil end
    local obj = game.get_master_player()
    if not obj then return nil end

    if m_state then
        local ok, v = pcall(function() return m_state:call(obj) end)
        if ok and type(v) == "boolean" then return v end
    end
    if m_damage then
        local ok, v = pcall(function() return m_damage:call(obj) end)
        if ok and type(v) == "boolean" then return v end
    end
    return nil
end

function hellfire.shake(reason)
    local obj = game.get_master_player()
    if not obj then return false, "沒有玩家物件" end
    if not resolve() then return false, "鬼火 API 不可用" end

    local state = hellfire.check_state()
    if state == nil then
        stats.fail = stats.fail + 1
        stats.last_reason = "讀不到鬼火狀態"
        return false, stats.last_reason
    end
    if state ~= true then
        stats.no_debuff = stats.no_debuff + 1
        stats.last_reason = "身上沒有鬼火"
        return false, stats.last_reason
    end

    local src = read_pos(obj)
    if not src then
        stats.pos_fail = stats.pos_fail + 1
        stats.last_reason = "讀不到玩家座標"
        return false, stats.last_reason
    end
    local pos = make_vec3(src)

    local ok_shell, err_shell = pcall(function() return m_shell:call(obj, pos, true) end)
    if not ok_shell then
        stats.fail = stats.fail + 1
        stats.last_reason = "setOniBombShell 失敗"
        log.warn("[HornResonance/hellfire] setOniBombShell 呼叫失敗：" .. tostring(err_shell))
        return false, stats.last_reason
    end

    local ok_clear, err_clear = pcall(function() return m_clear:call(obj, false) end)
    if not ok_clear then
        stats.fail = stats.fail + 1
        stats.last_reason = "clearOniBombDamage 失敗"
        log.warn("[HornResonance/hellfire] clearOniBombDamage 呼叫失敗：" .. tostring(err_clear))
        return false, stats.last_reason
    end

    stats.shakes = stats.shakes + 1
    stats.last_reason = "已甩掉鬼火"
    has_hellfire = false
    log.info(string.format("[HornResonance/hellfire] 甩掉鬼火 #%d（%s）→ 鬼火留在原地",
        stats.shakes, tostring(reason or "手動")))
    return true, stats.last_reason
end

function hellfire.update()
    if not resolve() then return end

    local obj = game.get_master_player()
    if not obj then
        has_hellfire = false
        return
    end

    has_hellfire = (hellfire.check_state() == true)

    if config.get("hellfire_shake_enabled") == false then return end

    local a = math.floor(game.get_action_id() or 0)
    if a ~= last_action then
        last_action = a
        if not is_target(a) then done_action = -1 end
    end

    if not is_target(a) then return end
    if done_action == a then return end

    local f = game.get_motion_frame()
    if type(f) ~= "number" then return end
    if f < need_frame() then return end

    if not has_hellfire then

        done_action = a
        stats.no_debuff = stats.no_debuff + 1
        stats.last_reason = string.format("action %d 沒有鬼火", a)
        if config.get("log_verbose") then
            log.info(string.format("[HornResonance/hellfire] action %d 幀 %.1f：身上沒有鬼火，跳過",
                a, f))
        end
        return
    end

    done_action = a
    local ok, why = hellfire.shake(string.format("action %d 幀 %.1f", a, f))
    if not ok then
        log.info(string.format("[HornResonance/hellfire] action %d 沒甩成：%s", a, tostring(why)))
    end
end

function hellfire.reset()
    last_action = -1
    done_action = -1
    has_hellfire = false
end

function hellfire.get_info()
    ensure_list()
    local actions = {}
    for a in pairs(parsed_actions or {}) do table.insert(actions, a) end
    table.sort(actions)

    return {
        enabled = config.get("hellfire_shake_enabled") ~= false,
        api_ok = (resolve_state == 1),
        api_tried = (resolve_state ~= 0),
        actions = table.concat(actions, ","),
        frame = need_frame(),
        action = game.get_action_id(),
        motion_frame = game.get_motion_frame() or 0.0,
        is_target = is_target(game.get_action_id()),
        has_hellfire = has_hellfire,
        done = (done_action == math.floor(game.get_action_id() or 0)),
        shakes = stats.shakes,
        no_debuff = stats.no_debuff,
        pos_fail = stats.pos_fail,
        fail = stats.fail,
        last_reason = stats.last_reason,
    }
end

function hellfire.dump()
    local i = hellfire.get_info()
    log.info("──────── HornResonance 甩鬼火（OniBomb）────────")
    log.info("  啟用       : " .. tostring(i.enabled))
    log.info("  API 狀態   : " .. (i.api_ok and "就緒" or (i.api_tried and "不可用" or "尚未嘗試")))
    log.info("  目標動作   : " .. (i.actions ~= "" and i.actions or "（無）"))
    log.info("  觸發幀數   : " .. i.frame)
    log.info("  身上有鬼火 : " .. tostring(i.has_hellfire))
    log.info(string.format("  目前 action: %d（幀 %.1f）%s",
        i.action, i.motion_frame, i.is_target and "（目標動作）" or ""))
    log.info("  甩掉次數   : " .. i.shakes)
    log.info("  沒鬼火     : " .. i.no_debuff .. " 次（到了幀數但身上沒有鬼火）")
    log.info("  座標失敗   : " .. i.pos_fail .. " 次")
    log.info("  呼叫失敗   : " .. i.fail .. " 次")
    log.info("  最近結果   : " .. tostring(i.last_reason))
    log.info("─────────────────────────────────────────────")
end

return hellfire
