local config = {}

local FILE_NAME = "horn_resonance_to_infernal.json"

local defaults = {
    enabled = true,
    infernal_node = 0x97FA77CF,
    log_verbose = false,

    config_version = 3,

    l2_combo_enabled = true,
    l2_tap_window = 0.25,
    l2_sticky_frames = 4,
    l2_cooldown = 0.6,
    l2_require_attack = true,
    l2_queue_enabled = true,
    l2_queue_timeout = 3.0,
    l2_use_derive = true,
    l2_cancel_ratio = 0.0,

    l2_override_enabled = true,
    l2_blocked_actions = "150,151,170",
    l2_override_frames = "152:180,158:180,163:180",

    derive_learn_enabled = false,
    derive_collect_enabled = false,

    hit_grace = 1.2,

    iframe_enabled = true,
    iframe_actions = "160,161,167,168,169",
    iframe_frames = 30,

    iframe_evade_enabled = true,
    iframe_evade_actions = "150",

    evade_cancel_enabled = true,
    evade_cancel_frame = 115,
    evade_cancel_node = 1731229352,
    evade_cancel_sticky = 6,

    evade_cancel_direction = true,
    evade_cancel_node_left = 1731229350,
    evade_cancel_node_right = 1731229351,
    evade_cancel_node_back = 3999410464,

    evade_cancel_early_enabled = true,
    evade_cancel_early_min = 30,
    evade_cancel_early_frames = 50,

    hellfire_shake_enabled = true,
    hellfire_shake_actions = "170",
    hellfire_shake_frame = 10,
}

local data = nil

local INT_KEYS = {
    config_version = true,
    infernal_node = true,
    l2_sticky_frames = true,
    iframe_frames = true,
    evade_cancel_frame = true,
    evade_cancel_node = true,
    evade_cancel_node_left = true,
    evade_cancel_node_right = true,
    evade_cancel_node_back = true,
    evade_cancel_sticky = true,
    evade_cancel_early_min = true,
    evade_cancel_early_frames = true,
    hellfire_shake_frame = true,
}

local CONFIG_VERSION = 3

function config.migrate_table(t)
    local v = tonumber(t.config_version) or 1
    if v >= CONFIG_VERSION then return t end

    if v < 2 then
        local b = tostring(t.l2_blocked_actions or "")

        if b == "" then
            t.l2_blocked_actions = "170"
        elseif b == "150,151" then
            t.l2_blocked_actions = "150,151,170"
        end
    end

    if v < 3 then
        local a = tostring(t.hellfire_shake_actions or "")

        if a == "159,170" then
            t.hellfire_shake_actions = "170"
        end
    end

    t.config_version = CONFIG_VERSION
    return t
end

function config.prepare_table(loaded)
    local src = (type(loaded) == "table") and loaded or {}
    local t = {}
    for k, v in pairs(defaults) do
        if src[k] ~= nil then t[k] = src[k] else t[k] = v end
    end
    t.config_version = tonumber(src.config_version) or 1
    return config.migrate_table(t)
end

local function normalize()
    for key in pairs(INT_KEYS) do
        local v = data[key]
        if type(v) == "number" then
            data[key] = math.floor(v)
        end
    end
end

local function load()
    if data then return data end
    local loaded = json.load_file(FILE_NAME)

    local raw_version = 1
    if type(loaded) == "table" and tonumber(loaded.config_version) then
        raw_version = math.floor(tonumber(loaded.config_version))
    end

    data = config.prepare_table(loaded)
    normalize()

    if (tonumber(data.config_version) or 0) ~= raw_version then
        if log and log.info then
            log.info(string.format(
                "[HornResonance/config] 設定檔已從 v%d 升級到 v%d（禁止 ZL 取消：%s ｜ 甩鬼火動作：%s）",
                raw_version, tonumber(data.config_version) or 0,
                tostring(data.l2_blocked_actions), tostring(data.hellfire_shake_actions)))
        end
        json.dump_file(FILE_NAME, data)
    end

    return data
end

local function save()
    json.dump_file(FILE_NAME, data)
end

function config.get(key)
    load()
    return data[key]
end

function config.set(key, value)
    load()
    if INT_KEYS[key] and type(value) == "number" then value = math.floor(value) end
    data[key] = value
    save()
end

function config.save()
    load()
    save()
end

function config.has_infernal_node()
    load()
    return data.infernal_node ~= nil and data.infernal_node ~= 0
end

function config.infernal_node_text()
    load()
    if not data.infernal_node or data.infernal_node == 0 then return "未設定" end
    return string.format("0x%08X", data.infernal_node)
end

return config
