local l2_combo = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")
local pad = require("horn_resonance/core/pad")
local wirebug = require("horn_resonance/core/wirebug")
local derive = require("horn_resonance/core/derive")
local rules = require("horn_resonance/core/rules")

local l2_down = false
local l2_down_time = 0.0
local l2_tainted = false
local consume_at_press = -1000.0

local sticky_left = 0
local skip_sticky = false
local last_trigger = -1000.0

local pending = nil

local ATK_WINDOW = 0.12

local cur_action = nil
local cur_max = 0.0
local cur_was_attack = false
local cur_jumped = false
local atk_recent_at = -1000.0
local last_attack_at = -1000.0

local trace_until = -1000.0
local trace_key = ""

local ACTION0_GRACE = 0.6

local ACTION0_BANKS = { [100] = true, [51] = true, [0] = true }

local stats = {
    taps = 0,
    triggers = 0,
    rejected = 0,
    ignored = 0,
    queued = 0,
    dropped = 0,
    by_derive = 0,
    by_override = 0,
    by_ratio = 0,
    by_end = 0,
    by_action0 = 0,
    last_reason = "—",
}

local function is_action0_window()
    if game.get_action_id() > 0 then return false end

    local grace = config.get("hit_grace") or 1.2
    if game.time_since_hit() < grace then return false end

    if game.is_attack() then

        return true
    end

    if (game.time() - last_attack_at) > ACTION0_GRACE then return false end
    return ACTION0_BANKS[game.get_bank_id()] == true
end

local function in_attack()
    if not config.get("l2_require_attack") then return true end

    if game.is_attack() then return true end

    if is_action0_window() then return true end

    return false
end

local function in_special_node()
    local node = game.get_current_node()
    if not node or node == 0 then return false end
    local infernal = config.get("infernal_node")
    if infernal and infernal ~= 0 and node == infernal then return true end
    return false
end

local function can_trigger()
    if not config.get("l2_combo_enabled") then return false, "L2 接技未啟用" end
    if not game.is_horn() then return false, "不是狩獵笛" end
    if not game.is_ready() then return false, "遊戲尚未就緒" end
    if pending then return false, "已有一個接技在等取消點" end

    local infernal = config.get("infernal_node")
    if not infernal or infernal == 0 then return false, "尚未設定氣焰旋律節點" end

    if in_special_node() then return false, "已在氣焰旋律中" end

    local grace = config.get("hit_grace") or 1.2
    local since_hit = game.time_since_hit()
    if since_hit < grace then
        return false, string.format("剛受擊（%.2f 秒前，受身保護 %.1f 秒）", since_hit, grace)
    end

    local ov_now = rules.get_override(game.get_action_id())
    if not ov_now and not in_attack() then return false, "不在一般攻擊中" end

    if not game.is_weapon_action() and not is_action0_window() then
        return false, string.format("非武器動作（bank %d），不搶按鍵", game.get_bank_id())
    end

    local action = game.get_action_id()
    if action <= 0 and not is_action0_window() then
        return false, string.format("動作尚未就緒（action %d / bank %d / 攻擊中 %s / 攻擊後 %.2f 秒）",
            action, game.get_bank_id(), tostring(game.is_attack()), game.time() - last_attack_at)
    end

    if rules.is_blocked(action) then
        return false, string.format("action %d 已設定為不可 ZL 取消", action)
    end

    local now = game.time()
    local cd = config.get("l2_cooldown") or 0.6
    if (now - last_trigger) < cd then return false, "冷卻中" end

    return true
end

local function do_trigger(now, why, kind)
    local infernal = config.get("infernal_node")
    if game.set_current_node(infernal) then
        sticky_left = math.floor(config.get("l2_sticky_frames") or 4)
        skip_sticky = true
        cur_jumped = true
        last_trigger = now
        stats.triggers = stats.triggers + 1
        if kind == "derive" then
            stats.by_derive = stats.by_derive + 1
        elseif kind == "override" then
            stats.by_override = stats.by_override + 1
        elseif kind == "ratio" then
            stats.by_ratio = stats.by_ratio + 1
        elseif kind == "end" then
            stats.by_end = stats.by_end + 1
        elseif kind == "action0" then
            stats.by_action0 = stats.by_action0 + 1
        end
        stats.last_reason = why or "觸發成功"
        log.info(string.format(
            "[HornResonance/l2] 派出氣焰旋律（%s；原 action %d / bank %d，黏著 %d 幀）",
            tostring(why), game.get_action_id(), game.get_bank_id(), sticky_left))
    else
        stats.last_reason = "setCurrentNode 失敗"
        log.warn("[HornResonance/l2] setCurrentNode 失敗（行為樹尚未取得？）")
    end
end

local function request(now)

    if is_action0_window() then
        do_trigger(now, "action 0 空窗，直接接技", "action0")
        return
    end

    local ov_now = rules.get_override(game.get_action_id())
    if config.get("l2_queue_enabled") and (game.is_attack() or ov_now) then
        pending = { at = now, action = game.get_action_id(), reanchor = 0 }
        stats.queued = stats.queued + 1
        stats.last_reason = "已排入佇列，等取消點"
        log.info(string.format(
            "[HornResonance/l2] 輕點成功 → 排入佇列（等 action %d 到取消點，逾時 %.1f 秒）",
            pending.action, config.get("l2_queue_timeout") or 3.0))
        return
    end
    do_trigger(now, "立即接技")
end

local function track_motion(now, st)
    local a = game.get_action_id()
    local f = game.get_motion_frame()
    local is_atk = game.is_attack()

    if st and st.attack_held then atk_recent_at = now end

    if is_atk then last_attack_at = now end

    if cur_action == nil then
        cur_action = a
        cur_max = (type(f) == "number") and f or 0.0
        cur_was_attack = is_atk
        cur_jumped = false
        return
    end

    if a ~= cur_action then

        local from, to, at = cur_action, a, cur_max
        local from_was_attack = cur_was_attack
        local self_jump = cur_jumped
        local atk = (now - atk_recent_at) <= ATK_WINDOW

        if from > 0 then

            derive.observe_derive({
                from = from,
                to = to,
                frame = at,
                mask = st and st.mask or 0,
                atk = atk,
                from_was_attack = from_was_attack,
                to_is_attack = is_atk,
                self_jump = self_jump,
            })

            if not self_jump and not is_atk then
                derive.observe_length(from, at)
            end
        end

        cur_action = a
        cur_max = (type(f) == "number") and f or 0.0
        cur_was_attack = is_atk
        cur_jumped = false
        return
    end

    if type(f) ~= "number" then return end

    if cur_max > 3.0 and (f + 3.0) < cur_max then
        if f <= 5.0 then
            local atk = (now - atk_recent_at) <= ATK_WINDOW
            if not cur_jumped and cur_was_attack and atk then

                derive.observe_derive({
                    from = cur_action,
                    to = cur_action,
                    frame = cur_max,
                    mask = st and st.mask or 0,
                    atk = true,
                    from_was_attack = true,
                    to_is_attack = is_atk,
                    self_jump = false,
                    allow_same = true,
                })
            elseif not cur_jumped then

                derive.observe_length(cur_action, cur_max)
            end
        end
        cur_max = f
        cur_was_attack = is_atk
        cur_jumped = false
        return
    end

    if f > cur_max then cur_max = f end
    if is_atk then cur_was_attack = true end
end

local function reached_cancel_point(action)
    local f = game.get_motion_frame()
    if type(f) ~= "number" then return nil, nil, nil end

    local ov = rules.get_override(action)
    if ov then return f >= ov, ov, "override" end

    if config.get("l2_use_derive") ~= false then
        local d = derive.get_derive(action)
        if d then return f >= d, d, "derive" end
    end

    local ratio = config.get("l2_cancel_ratio") or 0.0
    if ratio > 0.0 then
        local len = derive.get_length(action)
        if len and len >= 1.0 then
            local need = len * ratio
            return f >= need, need, "ratio"
        end
    end

    return nil, nil, nil
end

local function update_pending(now)
    if not pending then return end

    local timeout = config.get("l2_queue_timeout") or 3.0

    local wait_override = rules.get_override(pending.action)

    if not wait_override and (now - pending.at) > timeout then
        pending = nil
        stats.dropped = stats.dropped + 1
        stats.last_reason = "等待超時，接技取消"
        log.info("[HornResonance/l2] 等待逾時，接技取消")
        return
    end

    if in_special_node() then
        pending = nil
        stats.dropped = stats.dropped + 1
        stats.last_reason = "期間進入氣焰旋律，接技取消"
        return
    end

    local action_now = game.get_action_id()
    if action_now ~= pending.action then
        local new_ov = rules.get_override(action_now)
        if not game.is_attack() and not new_ov then

            pending = nil
            do_trigger(now, "攻擊已結束，接技", "end")
            return
        end

        if rules.is_blocked(action_now) then
            pending = nil
            stats.dropped = stats.dropped + 1
            stats.last_reason = string.format("換到 action %d（禁止 ZL 取消），接技取消", action_now)
            log.info(string.format(
                "[HornResonance/l2] 派生到 action %d（已設定禁止取消），接技取消", action_now))
            return
        end

        pending.action = action_now
        pending.reanchor = (pending.reanchor or 0) + 1
    end

    local reached, need, kind = reached_cancel_point(pending.action)
    if reached then
        pending = nil
        local label = (kind == "derive" and "派生取消點")
            or (kind == "override" and "手動指定取消點")
            or "比例取消點"
        do_trigger(now, string.format("到達%s（幀 %.0f / %.0f）",
            label, game.get_motion_frame(), need), kind)
        return
    end

    if not game.is_attack() and not rules.get_override(pending.action) then
        pending = nil
        do_trigger(now, "攻擊結束後接技", "end")
    end
end

function l2_combo.update()
    local now = game.time()

    pad.update(now)
    local st = pad.state()

    track_motion(now, st)

    wirebug.update()

    derive.tick(now)

    if now <= trace_until then
        local a, b, atk = game.get_action_id(), game.get_bank_id(), game.is_attack()
        local key = string.format("%d|%d|%s", a, b, tostring(atk))
        if key ~= trace_key then
            trace_key = key
            log.info(string.format(
                "[HornResonance/l2] trace action=%d bank=%d atk=%s 幀=%.1f 空窗=%s 攻擊後=%.2fs",
                a, b, tostring(atk), game.get_motion_frame(),
                tostring(is_action0_window()), now - last_attack_at))
        end
    end

    if not config.get("l2_combo_enabled") then
        l2_down = false
        sticky_left = 0
        pending = nil
        return
    end

    local hit_grace = config.get("hit_grace") or 1.2
    local hit_lock = game.time_since_hit() < hit_grace

    if hit_lock then
        sticky_left = 0
        if pending then
            pending = nil
            stats.dropped = stats.dropped + 1
            stats.last_reason = "受擊，接技取消"
        end
    else

        update_pending(now)

        if sticky_left > 0 and not skip_sticky then

            if not game.is_weapon_action() then
                sticky_left = 0
            else
                local infernal = config.get("infernal_node")
                local node = game.get_current_node()
                if node == infernal then

                    sticky_left = 0
                else
                    game.set_current_node(infernal)
                    sticky_left = sticky_left - 1
                end
            end
        end
    end
    skip_sticky = false

    if not st.ok then
        l2_down = false
        return
    end

    if st.l2_trg and not l2_down then
        l2_down = true
        l2_down_time = now
        l2_tainted = false
        consume_at_press = wirebug.get_last_consume_time() or -1000.0
    end

    if not l2_down then return end

    if st.r2_trg or st.l1_trg or st.r1_trg or st.b_held or st.b_trg then
        l2_tainted = true
    end
    local last_consume = wirebug.get_last_consume_time() or -1000.0
    if last_consume > consume_at_press + 0.001 then
        l2_tainted = true
    end

    if not st.l2_held then
        l2_down = false
        local held = now - l2_down_time
        local window = config.get("l2_tap_window") or 0.25

        if l2_tainted then
            stats.ignored = stats.ignored + 1
            stats.last_reason = "按住期間有其他輸入（判定為翔蟲技）"
        elseif held > window then
            stats.ignored = stats.ignored + 1
            stats.last_reason = string.format("按住 %.2f 秒，超過 %.2f（判定為長按）", held, window)
        else
            stats.taps = stats.taps + 1
            local ok, reason = can_trigger()
            if ok then
                request(now)
            else
                stats.rejected = stats.rejected + 1
                stats.last_reason = reason
            end
        end
    end
end

function l2_combo.get_stats()
    return stats
end

function l2_combo.trace_action0(seconds)
    local sec = seconds or 10.0
    trace_until = game.time() + sec
    trace_key = ""
    log.info(string.format(
        "[HornResonance/l2] action 0 診斷開始（%.0f 秒）：請先出一次下揮，之後看日誌的 trace 行", sec))
    return sec
end

function l2_combo.is_tracing()
    return game.time() <= trace_until
end

function l2_combo.dump_state()
    log.info("──────── HornResonance L2 接技 ────────")
    log.info("  啟用           : " .. tostring(config.get("l2_combo_enabled")))
    log.info("  輕點判定時間   : " .. tostring(config.get("l2_tap_window")) .. " 秒")
    log.info("  黏著幀數       : " .. tostring(config.get("l2_sticky_frames")))
    log.info("  冷卻           : " .. tostring(config.get("l2_cooldown")) .. " 秒")
    log.info("  限定攻擊中     : " .. tostring(config.get("l2_require_attack")))
    log.info("  等取消點才接   : " .. tostring(config.get("l2_queue_enabled"))
        .. "（逾時 " .. tostring(config.get("l2_queue_timeout")) .. " 秒）")
    log.info("  用派生取消點   : " .. tostring(config.get("l2_use_derive")))
    log.info("  比例退路       : " .. tostring(config.get("l2_cancel_ratio"))
        .. "（0 = 關閉，改等攻擊結束）")
    log.info("  L2 目前狀態    : " .. (l2_down and "按住中" or "放開"))
    log.info("  佇列           : " .. (pending
        and string.format("等待中（action %d，已等 %.2f 秒，換過 %d 次動作）",
            pending.action, game.time() - pending.at, pending.reanchor or 0)
        or "空"))

    local a = game.get_action_id()
    local d = derive.get_derive(a)
    local len = derive.get_length(a)
    local ov = rules.get_override(a)
    log.info(string.format("  目前 action    : %d / bank %d   幀 %.1f",
        a, game.get_bank_id(), game.get_motion_frame()))
    log.info("  本動作派生點   : " .. (d and string.format("%.0f 幀", d) or "尚未學到"))
    log.info("  本動作手動指定 : " .. (ov and string.format("%.0f 幀", ov) or "無"))
    log.info("  本動作是否封鎖 : " .. tostring(rules.is_blocked(a)))
    log.info("  本動作總長     : " .. (len and string.format("%.0f 幀", len) or "尚未學到"))
    log.info("  已學習派生點   : " .. derive.count() .. " 個動作")
    log.info("  手動規則       : " .. rules.summary())
    log.info("  黏著剩餘       : " .. sticky_left)
    log.info("  輕點次數       : " .. stats.taps)
    log.info("  觸發次數       : " .. stats.triggers
        .. string.format("（派生點 %d / 手動 %d / 比例 %d / 攻擊結束 %d / action0 %d）",
            stats.by_derive, stats.by_override, stats.by_ratio, stats.by_end, stats.by_action0))
    log.info("  條件不符       : " .. stats.rejected)
    log.info("  非輕點忽略     : " .. stats.ignored)
    log.info("  排入佇列       : " .. stats.queued)
    log.info("  等待逾時丟棄   : " .. stats.dropped)
    log.info("  最近結果       : " .. stats.last_reason)
    log.info("  是否攻擊中     : " .. tostring(game.is_attack())
        .. "（isActionStatusTag(Attack)）")
    log.info(string.format("  action 0 空窗  : %s（目前 action %d / bank %d，攻擊後 %.2f 秒）",
        tostring(is_action0_window()), game.get_action_id(), game.get_bank_id(),
        game.time() - last_attack_at))
    log.info(string.format("  受擊保護       : 距上次受擊 %.2f 秒（門檻 %.1f 秒）%s",
        game.time_since_hit(), config.get("hit_grace") or 1.2,
        game.time_since_hit() < (config.get("hit_grace") or 1.2) and "→ 停手中" or ""))
    log.info("  武器動作中     : " .. tostring(game.is_weapon_action())
        .. string.format("（bank %d）", game.get_bank_id()))
    log.info("  目前節點       : " .. string.format("0x%08X", game.get_current_node() or 0))
    log.info("─────────────────────────────────────")
end

function l2_combo.reset()
    l2_down = false
    l2_tainted = false
    sticky_left = 0
    pending = nil
    last_trigger = -1000.0
    cur_action = nil
    cur_max = 0.0
    cur_was_attack = false
    cur_jumped = false
    atk_recent_at = -1000.0
    last_attack_at = -1000.0
    trace_until = -1000.0
    trace_key = ""
    pad.reset()
    wirebug.reset()
end

function l2_combo.is_pending()
    return pending ~= nil
end

function l2_combo.get_pending_info()
    if not pending then return nil end
    return {
        action = pending.action,
        waited = game.time() - pending.at,
        reanchor = pending.reanchor or 0,
    }
end

function l2_combo.get_debug_info()
    local a = game.get_action_id()
    local d = derive.get_derive(a)
    local len = derive.get_length(a)
    local ratio = config.get("l2_cancel_ratio") or 0.0
    local ov = rules.get_override(a)
    local blocked = rules.is_blocked(a)
    local need, source
    if blocked then
        source = "blocked"
    elseif ov then
        need, source = ov, "override"
    elseif d and config.get("l2_use_derive") ~= false then
        need, source = d, "derive"
    elseif ratio > 0.0 and len then
        need, source = len * ratio, "ratio"
    end
    return {
        action = a,
        frame = game.get_motion_frame(),
        bank = game.get_bank_id(),
        derive = d,
        length = len,
        override = ov,
        blocked = blocked,
        need = need,
        source = source,
        learned_count = derive.count(),
        action0_window = is_action0_window(),
        is_weapon_action = game.is_weapon_action(),
        is_attack = game.is_attack(),
        since_hit = game.time_since_hit(),
        hit_grace = config.get("hit_grace") or 1.2,
    }
end

return l2_combo
