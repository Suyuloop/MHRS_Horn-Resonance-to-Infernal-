local seed = {}

seed.derives = {
    { from = 101, to = 101, frame = 74,  len = 104 },
    { from = 102, to = 102, frame = 90,  len = 114 },
    { from = 103, to = 103, frame = 99,  len = 222 },
    { from = 105, to = 105, frame = 70,  len = 156 },
    { from = 106, to = 106, frame = 82,  len = 136 },
    { from = 143, to = 143, frame = 60,  len = 89 },
    { from = 144, to = 144, frame = 90,  len = 193 },
    { from = 145, to = 145, frame = 60,  len = 64 },
    { from = 149, to = 149, frame = 96,  len = 230 },
    { from = 150, to = 150, frame = 145, len = 204 },
    { from = 151, to = 151, frame = 120, len = 186 },
    { from = 159, to = 159, frame = 290, len = 345 },
    { from = 160, to = 160, frame = 120, len = 158 },
    { from = 161, to = 161, frame = 120, len = 160 },
    { from = 164, to = 164, frame = 10 },
    { from = 166, to = 166, frame = 150, len = 203 },
    { from = 167, to = 167, frame = 120, len = 168 },
    { from = 168, to = 168, frame = 150, len = 168 },
    { from = 169, to = 169, frame = 150, len = 168 },
    { from = 173, to = 173, frame = 45,  len = 136 },
}

seed.version = 1

return seed
