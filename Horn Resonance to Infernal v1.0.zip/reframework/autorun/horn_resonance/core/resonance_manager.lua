local resonance_manager = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")
local l2_combo = require("horn_resonance/core/l2_combo")
local iframe = require("horn_resonance/core/iframe")
local evade_cancel = require("horn_resonance/core/evade_cancel")
local hellfire = require("horn_resonance/core/hellfire")

function resonance_manager.reset()
    l2_combo.reset()
    iframe.reset()
    evade_cancel.reset()
    hellfire.reset()
end

function resonance_manager.pre_update()
    if not config.get("enabled") then return end
    if not game.is_horn() then return end
    if not game.is_ready() then return end

    iframe.update()

    l2_combo.update()

    evade_cancel.update()

    hellfire.update()
end

return resonance_manager
