local wirebug = {}

local game = require("horn_resonance/core/game")

local M_USABLE = "getUsableHunterWireNum"

local last_count = nil
local last_consume_time = -1000.0

function wirebug.update()
    local mp = game.get_master_player()
    if not mp then
        last_count = nil
        return
    end

    local ok, v = pcall(function() return mp:call(M_USABLE) end)
    if not ok or type(v) ~= "number" then return end

    if last_count and v < last_count then
        last_consume_time = game.time()
    end
    last_count = v
end

function wirebug.get_last_consume_time()
    return last_consume_time
end

function wirebug.get_count()
    return last_count
end

function wirebug.reset()
    last_count = nil
    last_consume_time = -1000.0
end

return wirebug
