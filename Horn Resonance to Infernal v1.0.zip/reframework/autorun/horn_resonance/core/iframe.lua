local iframe = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")

local FLOW_NO_EXECUTE_SAVE = 2

local FROZEN_SECONDS = 0.25

local function split(s, sep)
    local out = {}
    local pos = 1
    while true do
        local i = string.find(s, sep, pos, true)
        if not i then
            local tail = string.sub(s, pos)
            if tail ~= "" then table.insert(out, tail) end
            break
        end
        local piece = string.sub(s, pos, i - 1)
        if piece ~= "" then table.insert(out, piece) end
        pos = i + #sep
    end
    return out
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function build_set(raw)
    local set, names = {}, {}
    for _, tok in ipairs(split(raw, ",")) do
        local n = tonumber(trim(tok))
        if n and n > 0 then
            set[math.floor(n)] = true
            table.insert(names, tostring(math.floor(n)))
        end
    end
    return set, names
end

local cached_actions, parsed_actions = nil, nil
local cached_native, parsed_native = nil, nil

local function ensure_lists()
    local raw = tostring(config.get("iframe_actions") or "")
    if raw ~= cached_actions then
        cached_actions = raw
        local names
        parsed_actions, names = build_set(raw)
        log.info("[HornResonance/iframe] 迴避判定動作：" ..
            (#names > 0 and table.concat(names, ", ") or "（無）"))
    end

    local raw_n = tostring(config.get("iframe_evade_actions") or "")
    if raw_n ~= cached_native then
        cached_native = raw_n
        local names
        parsed_native, names = build_set(raw_n)
        log.info("[HornResonance/iframe] 原生無敵補迴避判定的動作：" ..
            (#names > 0 and table.concat(names, ", ") or "（無）"))
    end
end

local function is_target(action, set)
    local a = math.floor(action or 0)
    if a <= 0 then return false end
    return set ~= nil and set[a] == true
end

local window_open = false
local applied = 0
local native_muteki = false
local suppress_action = nil

local last_motion_frame = -1.0
local frame_changed_at = 0.0
local motion_frozen = false

local last_escape_frame = -9999.0
local last_escape_at = -9999.0

local stats = {
    windows = 0,
    blocked_damage = 0,
    missed_hits = 0,
    forced_muteki = 0,
    forced_escape = 0,
    escape_hits = 0,
    escape_calls = 0,
    escape_fail = 0,
    muteki_calls = 0,
    muteki_master = 0,
    damage_calls = 0,
    updates = 0,
}

local function refresh_motion_alive()
    local now = game.time()
    local f = game.get_motion_frame()
    if type(f) ~= "number" then f = 0.0 end

    if f ~= last_motion_frame then
        last_motion_frame = f
        frame_changed_at = now
        motion_frozen = false
        return false
    end

    motion_frozen = (now - frame_changed_at) > FROZEN_SECONDS
    return motion_frozen
end

local function head_window()
    local max_frames = math.floor(config.get("iframe_frames") or 10)
    if max_frames <= 0 then return false end
    local f = game.get_motion_frame()
    if type(f) ~= "number" then return false end
    return f <= max_frames
end

function iframe.update()
    ensure_lists()

    native_muteki = game.is_native_muteki()
    refresh_motion_alive()
    stats.updates = stats.updates + 1

    local a = game.get_action_id()

    if suppress_action ~= nil and a ~= suppress_action then
        suppress_action = nil
    end

    local was_open = window_open
    window_open = iframe.is_active()

    if window_open then
        local f = game.get_motion_frame()
        applied = (type(f) == "number") and math.max(1, math.floor(f) + 1) or 1
        if not was_open then
            stats.windows = stats.windows + 1
            local max_frames = math.floor(config.get("iframe_frames") or 10)
            log.info(string.format(
                "[HornResonance/iframe] action %d 起手（幀 %.1f）→ 無敵 %d 幀（約 %.2f 秒）",
                a, f or 0.0, max_frames, max_frames / 60.0))
        end
    else
        applied = 0
    end
end

local function ptr_to_int(p)
    if p == nil then return nil end
    if type(p) == "number" then return p end

    local ok, v = pcall(function() return sdk.to_int64(p) end)
    if ok and type(v) == "number" then return v end

    local hex = string.match(tostring(p), "0x(%x+)")
    if hex then
        local n = tonumber(hex, 16)
        if n then return n end
    end

    return nil
end

function iframe.is_active()
    if config.get("iframe_enabled") == false then return false end

    local a = game.get_action_id()

    if suppress_action ~= nil and a == suppress_action then return false end

    if is_target(a, parsed_actions) and head_window() and not motion_frozen then
        return true
    end

    if config.get("iframe_evade_enabled") == false then return false end
    if native_muteki and is_target(a, parsed_native) then
        return true
    end

    return false
end

function iframe.is_blocking()
    return iframe.is_active()
end

function iframe.should_evade_check()
    if config.get("iframe_evade_enabled") == false then return false end
    return iframe.is_active()
end

function iframe.is_native_muteki()
    return native_muteki
end

function iframe.override_muteki(retval)
    if not iframe.is_active() then return retval end
    stats.forced_muteki = stats.forced_muteki + 1
    return sdk.to_ptr(1)
end

function iframe.override_damage_flow(retval, target)
    local act = game.get_action_id()

    if not iframe.is_active() then

        game.note_hit()

        stats.missed_hits = stats.missed_hits + 1
        log.info(string.format(
            "[HornResonance/iframe] 受擊 #%d 未攔截：action=%d 幀=%s 窗口=關 原生無敵=%s",
            stats.damage_calls, act, tostring(game.get_motion_frame()),
            tostring(native_muteki)))
        return retval
    end

    stats.blocked_damage = stats.blocked_damage + 1

    local orig = ptr_to_int(retval)

    log.info(string.format(
        "[HornResonance/iframe] 受擊 #%d 攔下：action=%d 幀=%s 來源=%s 原判定=%s",
        stats.damage_calls, act, tostring(game.get_motion_frame()),
        window_open and "窗口" or "原生無敵",
        orig ~= nil and tostring(orig) or "讀不到"))

    if config.get("iframe_evade_enabled") ~= false then
        local f = game.get_motion_frame()
        if type(f) ~= "number" then f = -9999.0 end
        local now = game.time()
        local dup = (f == last_escape_frame) and ((now - last_escape_at) < 0.5)
        if not dup then
            last_escape_frame = f
            last_escape_at = now
            iframe.register_escape(target)
        end
    end

    return sdk.to_ptr(FLOW_NO_EXECUTE_SAVE)
end

local function probe_skill(obj)
    local timer = "?"
    local ok_t, v = pcall(function() return obj:get_field("_CheckEquipSkill209Timer") end)
    if ok_t and type(v) == "number" then timer = string.format("%.2f", v) end

    local active = "?"
    local ok_a, s = pcall(function() return obj:call("getActiveEquipSkill209") end)
    if ok_a then active = (s ~= nil) and "有" or "無" end

    return string.format("skill209{ timer=%s, active=%s }", timer, active)
end

function iframe.register_escape(target)
    local obj = target or game.get_master_player()
    if not obj then
        stats.escape_fail = stats.escape_fail + 1
        return false
    end

    local before = probe_skill(obj)

    local ok, err = pcall(function() obj:call("callbackEscapeCheckHit") end)
    if ok then
        stats.escape_calls = stats.escape_calls + 1

        if stats.escape_calls <= 5 then
            log.info("[HornResonance/iframe] 補發迴避成功 #" .. stats.escape_calls
                .. " → " .. before .. " → " .. probe_skill(obj))
        end
    else
        stats.escape_fail = stats.escape_fail + 1

        if stats.escape_fail <= 3 then
            log.warn("[HornResonance/iframe] callbackEscapeCheckHit 呼叫失敗：" .. tostring(err))
        end
    end
    return ok
end

function iframe.override_escape_check(retval)
    if not iframe.should_evade_check() then return retval end
    stats.forced_escape = stats.forced_escape + 1
    return sdk.to_ptr(1)
end

function iframe.get_skill_state()
    local obj = game.get_master_player()
    if not obj then return nil end
    return probe_skill(obj)
end

function iframe.note_muteki_call(is_master)
    stats.muteki_calls = stats.muteki_calls + 1
    if is_master then stats.muteki_master = stats.muteki_master + 1 end
end

function iframe.note_damage_call()
    stats.damage_calls = stats.damage_calls + 1
end

function iframe.note_escape_hit()
    stats.escape_hits = stats.escape_hits + 1
end

function iframe.close()
    window_open = false
    applied = 0
    suppress_action = game.get_action_id() or 0
end

function iframe.reset()
    iframe.close()
    last_motion_frame = -1.0
    frame_changed_at = 0.0
    motion_frozen = false
    last_escape_frame = -9999.0
    last_escape_at = -9999.0
end

function iframe.get_info()
    local max_frames = math.floor(config.get("iframe_frames") or 10)
    local a = game.get_action_id()
    local f = game.get_motion_frame()
    if type(f) ~= "number" then f = 0.0 end
    return {
        enabled = config.get("iframe_enabled") ~= false,
        evade_enabled = config.get("iframe_evade_enabled") ~= false,
        actions = tostring(config.get("iframe_actions") or ""),
        evade_actions = tostring(config.get("iframe_evade_actions") or ""),
        frames = max_frames,
        action = a,
        motion_frame = f,
        is_target = is_target(a, parsed_actions),
        is_evade_target = is_target(a, parsed_native),
        native_muteki = native_muteki,
        motion_frozen = motion_frozen,
        window_open = window_open,
        applied = applied,
        remaining = (max_frames > applied) and (max_frames - applied) or 0,
        evade_check = iframe.should_evade_check(),
        windows = stats.windows,
        blocked_damage = stats.blocked_damage,
        missed_hits = stats.missed_hits,
        forced_escape = stats.forced_escape,
        escape_hits = stats.escape_hits,
        escape_calls = stats.escape_calls,
        escape_fail = stats.escape_fail,
        muteki_calls = stats.muteki_calls,
        muteki_master = stats.muteki_master,
        damage_calls = stats.damage_calls,
        updates = stats.updates,
    }
end

function iframe.dump()
    local i = iframe.get_info()
    log.info("──────── HornResonance 迴避判定 ────────")
    log.info("  啟用       : " .. tostring(i.enabled)
        .. "（迴避判定 " .. tostring(i.evade_enabled) .. "）")
    log.info("  無敵動作   : " .. i.actions)
    log.info("  原生無敵補迴避 : " .. i.evade_actions)
    log.info("  窗口幀數   : " .. i.frames)
    log.info("  目前 action: " .. i.action
        .. string.format("（幀 %.1f）", i.motion_frame)
        .. (i.is_target and "（無敵清單）" or "")
        .. (i.is_evade_target and "（原生迴避清單）" or ""))
    log.info("  窗口狀態   : " .. (i.window_open and
        string.format("開（已過 %d 幀，剩 %d 幀）", i.applied, i.remaining) or "關"))
    log.info("  動作幀數   : " .. (i.motion_frozen and "已停住（視為動作結束）" or "前進中"))
    log.info("  原生無敵中 : " .. tostring(i.native_muteki))
    log.info("  迴避判定   : " .. (i.evade_check and "開啟中" or "關閉"))
    log.info("  開窗次數   : " .. i.windows)
    log.info("  擋下傷害   : " .. i.blocked_damage .. " 次")
    log.info("  未攔截受擊 : " .. i.missed_hits .. " 次（受擊時窗口是關的）")
    log.info("  開啟迴避檢查: " .. i.forced_escape .. " 次")
    log.info("  補發迴避成功: " .. i.escape_calls .. " 次（主動呼叫 callbackEscapeCheckHit）")
    log.info("  迴避成功   : " .. i.escape_hits .. " 次（callbackEscapeCheckHit）")
    if i.escape_fail > 0 then
        log.info("  補發失敗   : " .. i.escape_fail .. " 次")
    end
    log.info("  ── 診斷 ──")
    log.info("  update 呼叫        : " .. i.updates)
    log.info("  checkMuteki 呼叫   : " .. i.muteki_calls
        .. "（主玩家 " .. i.muteki_master .. "）")
    log.info("  傷害判定呼叫       : " .. i.damage_calls)
    log.info("─────────────────────────────────────")
end

return iframe
