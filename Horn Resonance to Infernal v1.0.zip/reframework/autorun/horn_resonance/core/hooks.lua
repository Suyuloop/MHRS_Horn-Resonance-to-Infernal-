local hooks = {}

local game = require("horn_resonance/core/game")
local resonance_manager = require("horn_resonance/core/resonance_manager")
local iframe = require("horn_resonance/core/iframe")

local installed = false
local active = false

local function safe_hook(type_name, method_name, pre, post)
    local ok_td, td = pcall(sdk.find_type_definition, type_name)
    if not ok_td or not td then
        log.warn("[HornResonance] type not found: " .. type_name)
        return false
    end
    local ok_md, md = pcall(td.get_method, td, method_name)
    if not ok_md or not md then
        log.warn("[HornResonance] method not found: " .. type_name .. "::" .. method_name)
        return false
    end
    local ok_hook, err = pcall(sdk.hook, md, pre, post)
    if not ok_hook then
        log.warn("[HornResonance] hook failed: " .. type_name .. "::" .. method_name .. " " .. tostring(err))
        return false
    end
    log.info("[HornResonance] hooked " .. type_name .. "::" .. method_name)
    return true
end

local function pre_motion_control_late_update(args)
    local ok, err = pcall(function()
        local this = sdk.to_managed_object(args[2])
        if not this then return end
        local base = this:get_field("_RefPlayerBase")
        if not base or not base:isMasterPlayer() then return end
        game.set_action(this:get_field("_OldMotionID"), this:get_field("_OldBankID"))
    end)
    if not ok then
        log.warn("[HornResonance] lateUpdate error: " .. tostring(err))
    end
end

local function pre_horn_update(args)
    if not active then return end
    local ok, err = pcall(function()
        local this = sdk.to_managed_object(args[2])
        if not this then return end
        if not this:isMasterPlayer() then return end
        game.sample_motion()
        resonance_manager.pre_update()
    end)
    if not ok then
        log.warn("[HornResonance] pre_horn_update error: " .. tostring(err))
    end
end

local function hook_storage()
    local ok, s = pcall(function() return thread.get_hook_storage() end)
    if ok then return s end
    return nil
end

local function pre_damage_side(args)
    if not active then return end
    iframe.note_damage_call()

    local this = nil
    pcall(function() this = sdk.to_managed_object(args[2]) end)

    local is_master = true
    if this then
        local ok, v = pcall(function() return this:isMasterPlayer() end)
        if ok and v == false then is_master = false end
    end

    local storage = hook_storage()
    if storage then
        storage.is_master = is_master
        storage.player = this
    end
end

local function post_damage_side(retval)
    if not active then return retval end
    local storage = hook_storage()
    if storage and storage.is_master == false then return retval end
    return iframe.override_damage_flow(retval, storage and storage.player)
end

local function post_escape_check(retval)
    if not active then return retval end
    return iframe.override_escape_check(retval)
end

local function post_escape_check_hit()
    if not active then return end
    iframe.note_escape_hit()
end

local function pre_check_muteki(args)
    if not active then return end
    local ok, is_master = pcall(function()
        local this = sdk.to_managed_object(args[2])
        return this ~= nil and this:isMasterPlayer()
    end)
    iframe.note_muteki_call((ok and is_master) or false)
end

local function post_check_muteki(retval)
    if not active then return retval end
    return iframe.override_muteki(retval)
end

local function install()
    if installed then return end
    installed = true

    safe_hook("snow.player.PlayerMotionControl", "lateUpdate", pre_motion_control_late_update)

    safe_hook("snow.player.Horn", "update", pre_horn_update)

    safe_hook("snow.player.PlayerQuestBase", "checkCalcDamage_DamageSide",
        pre_damage_side, post_damage_side)

    safe_hook("snow.player.PlayerQuestBase", "isEnableEscapeDamageCheck", nil, post_escape_check)
    safe_hook("snow.player.PlayerQuestBase", "callbackEscapeCheckHit", nil, post_escape_check_hit)

    safe_hook("snow.player.PlayerQuestBase", "checkMuteki", pre_check_muteki, post_check_muteki)
end

function hooks:enable_hooks()
    install()
    active = true
end

function hooks:disable_hooks()
    active = false

    iframe.close()
end

function hooks:is_active()
    return active
end

return hooks
