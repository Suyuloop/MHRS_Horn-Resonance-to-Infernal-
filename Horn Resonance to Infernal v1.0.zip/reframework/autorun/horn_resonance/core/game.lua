local game = {}

local HORN_WEAPON_TYPE = 10

local PlayerManager = nil
local master_player = nil
local master_addr = nil
local behavior_tree = nil
local bt_type = nil
local weapon_type = -1

local action_id = -1
local bank_id = -1
local motion_frame = 0.0
local frame_warned = false
local current_node = 0

function game.refresh_world()
    if not PlayerManager then
        local ok, pm = pcall(sdk.get_managed_singleton, "snow.player.PlayerManager")
        if ok then PlayerManager = pm end
    end
    if not PlayerManager then return end

    local ok_mp, mp = pcall(function() return PlayerManager:call("findMasterPlayer") end)
    if not ok_mp or not mp then
        master_player = nil
        behavior_tree = nil
        master_addr = nil
        weapon_type = -1
        return
    end

    local ok_master, is_master = pcall(function() return mp:isMasterPlayer() end)
    if not ok_master or not is_master then
        master_player = nil
        behavior_tree = nil
        master_addr = nil
        weapon_type = -1
        return
    end

    master_player = mp

    local ok_w, wt = pcall(function() return mp:get_field("_playerWeaponType") end)
    weapon_type = (ok_w and type(wt) == "number") and wt or -1

    local ok_addr, addr = pcall(function() return mp:get_address() end)
    local need_refresh = true
    if ok_addr and addr ~= nil then
        if addr == master_addr then need_refresh = false end
        master_addr = addr
    end

    if need_refresh then
        local ok_go, go = pcall(function() return mp:call("get_GameObject") end)
        if ok_go and go then
            if not bt_type then
                local ok_t, t = pcall(sdk.typeof, "via.behaviortree.BehaviorTree")
                if ok_t then bt_type = t end
            end
            if bt_type then
                local ok_bt, bt = pcall(function()
                    return go:call("getComponent(System.Type)", bt_type)
                end)
                if ok_bt then behavior_tree = bt end
            end
        end
    end
end

function game.set_action(new_action_id, new_bank_id)
    action_id = new_action_id or -1
    bank_id = new_bank_id or -1
end

function game.get_action_id()
    return action_id
end

function game.get_bank_id()
    return bank_id
end

local last_hit_at = -1000.0

function game.note_hit()
    last_hit_at = game.time()
end

function game.time_since_hit()
    return game.time() - last_hit_at
end

local WEAPON_BANK = 100

function game.is_weapon_action()
    return bank_id == WEAPON_BANK
end

function game.sample_motion()
    if not master_player then return end

    local ok_f, f = pcall(function()
        return master_player:call("getMotionNowFrame_Layer", 0)
    end)
    if ok_f and type(f) == "number" then
        motion_frame = f
    else

        local ok_g, g = pcall(function()
            return master_player:call("getMotionLayer", 0):call("get_Frame")
        end)
        if ok_g and type(g) == "number" then
            motion_frame = g
        elseif not frame_warned then
            frame_warned = true
            log.warn("[HornResonance] getMotionNowFrame_Layer 讀不到，取消點判斷會退回「等攻擊結束」")
        end
    end

    if behavior_tree then
        local ok_n, n = pcall(function() return behavior_tree:call("getCurrentNodeID", 0) end)
        if ok_n and type(n) == "number" then current_node = n end
    end
end

function game.get_motion_frame()
    return motion_frame
end

function game.get_frame()
    return motion_frame
end

function game.get_current_node()
    return current_node
end

function game.set_current_node(node_hash)
    if not behavior_tree then return false end
    local ok = pcall(function()
        behavior_tree:call("setCurrentNode", node_hash, nil, nil)
    end)
    return ok
end

function game.get_master_player()
    return master_player
end

function game.get_weapon_type()
    return weapon_type
end

function game.is_horn()
    return weapon_type == HORN_WEAPON_TYPE
end

function game.is_ready()
    return master_player ~= nil
end

local muteki_ok = nil

function game.get_muteki_time()
    if not master_player then return nil end
    if muteki_ok == false then return nil end
    local ok, v = pcall(function() return master_player:get_field("_MutekiTime") end)
    if ok and type(v) == "number" then
        muteki_ok = true
        return v
    end
    if muteki_ok == nil then
        muteki_ok = false
        log.warn("[HornResonance] 讀不到 _MutekiTime，原生無敵偵測停用（不影響其他功能）")
    end
    return nil
end

function game.is_native_muteki()
    local v = game.get_muteki_time()
    return v ~= nil and v > 0.0
end

local ACT_STATUS_ATTACK = 0xBA3555F8

local act_status_state = 0

function game.get_state_action_type()
    if not master_player then return nil end
    local ok, v = pcall(function() return master_player:call("getStateActionType") end)
    if ok and type(v) == "number" then return v end
    return nil
end

function game.is_attack()
    if not master_player then return false end

    if act_status_state >= 0 then
        local ok, v = pcall(function()
            return master_player:call("isActionStatusTag", ACT_STATUS_ATTACK)
        end)
        if ok and type(v) == "boolean" then
            if act_status_state == 0 then
                act_status_state = 1
                log.info("[HornResonance] 攻擊判斷：使用 isActionStatusTag(ActStatus.Attack)")
            end
            return v
        end
        act_status_state = -1
        log.warn("[HornResonance] isActionStatusTag 呼叫失敗，改用 getStateActionType 判斷")
    end

    local t = game.get_state_action_type()
    if t ~= nil then return t ~= 0 end
    return false
end

local app_uptime_method = nil
local app_delta_method = nil
local app_checked = false

local function ensure_app_methods()
    if app_checked then return end
    app_checked = true
    local ok_td, td = pcall(sdk.find_type_definition, "via.Application")
    if not ok_td or not td then return end
    local ok1, m1 = pcall(td.get_method, td, "get_UpTimeSecond")
    if ok1 then app_uptime_method = m1 end
    local ok2, m2 = pcall(td.get_method, td, "get_ElapsedSecond")
    if ok2 then app_delta_method = m2 end
end

function game.time()
    ensure_app_methods()
    if app_uptime_method then
        local ok, v = pcall(function() return app_uptime_method:call(nil) end)
        if ok and type(v) == "number" then return v end
    end
    return os.clock()
end

function game.delta_time()
    ensure_app_methods()
    if app_delta_method then
        local ok, v = pcall(function() return app_delta_method:call(nil) end)
        if ok and type(v) == "number" and v > 0 then return v end
    end
    return 1.0 / 60.0
end

return game
