local pad = {}

local game = require("horn_resonance/core/game")

local BIT_L1 = 0x100
local BIT_L2 = 0x200
local BIT_R1 = 0x400
local BIT_R2 = 0x800

local BIT_X = 0x10
local BIT_A = 0x80
local BIT_DECIDE = 0x20000

local BIT_B = 0x20

local BIT_ELU = 0x100000
local BIT_ELR = 0x200000
local BIT_ELD = 0x400000
local BIT_ELL = 0x800000
local BIT_CC = 0x10000

local singleton = nil
local device = nil
local device_field = "—"
local device_at = -1000.0

local prev_mask = 0
local have_prev = false
local last_update_at = -1000.0

local st = {
    l2_held = false,
    l2_trg = false,
    l2_rel = false,
    r2_trg = false,
    l1_trg = false,
    r1_trg = false,
    x_held = false,
    a_held = false,
    xa_held = false,
    attack_held = false,
    attack_trg = false,
    b_held = false,
    b_trg = false,
    dir = nil,
    mask = 0,
    ok = false,
}

local function has_bit(m, bit)
    return m % (bit * 2) >= bit
end

local function get_singleton()
    if singleton then return singleton end
    local ok, s = pcall(sdk.get_managed_singleton, "snow.Pad")
    if ok and s then
        singleton = s
        return s
    end
    return nil
end

local function get_device(now)
    if device and (now - device_at) < 3.0 then return device end
    device_at = now
    device = nil
    device_field = "—"

    local s = get_singleton()
    if not s then return nil end

    for _, name in ipairs({ "app", "hard", "sys" }) do
        local ok, d = pcall(function() return s:get_field(name) end)
        if ok and d then
            device = d
            device_field = name
            return d
        end
    end

    return nil
end

local function to_num(v)
    if type(v) == "number" then return v end
    if v == nil then return nil end
    local ok, n = pcall(function() return sdk.to_int64(v) end)
    if ok and type(n) == "number" then return n end
    return nil
end

local function call_num(dev, name)
    local ok, v = pcall(function() return dev:call(name) end)
    if not ok then return nil end
    return to_num(v)
end

local function read_mask(dev)
    local m = call_num(dev, "get_on")
    if m then return m end

    local mask = 0
    local function probe(name, bit)
        local ok, v = pcall(function() return dev:call(name) end)
        if ok and v == true then mask = mask + bit end
    end
    probe("getLTButtonOrTrg", BIT_L1)
    probe("getLBButtonOrTrg", BIT_L2)
    probe("getRTButtonOrTrg", BIT_R1)
    probe("getRBButtonOrTrg", BIT_R2)
    if mask > 0 then return mask end
    return nil
end

local function mask_to_dir(m)
    if has_bit(m, BIT_ELU) or has_bit(m, BIT_CC) then return "front" end
    if has_bit(m, BIT_ELD) then return "back" end
    if has_bit(m, BIT_ELL) then return "left" end
    if has_bit(m, BIT_ELR) then return "right" end
    return nil
end

function pad.update(now)
    now = now or 0.0

    st.ok = false
    st.l2_trg = false
    st.l2_rel = false
    st.r2_trg = false
    st.l1_trg = false
    st.r1_trg = false
    st.attack_trg = false
    st.b_trg = false
    st.dir = nil

    local dev = get_device(now)
    if not dev then
        st.l2_held = false
        st.x_held = false
        st.a_held = false
        st.xa_held = false
        st.attack_held = false
        st.b_held = false
        st.mask = 0
        have_prev = false
        return
    end

    if now - last_update_at > 0.10 then
        have_prev = false
    end
    last_update_at = now

    local mask = read_mask(dev)
    if mask == nil then
        st.l2_held = false
        st.x_held = false
        st.a_held = false
        st.xa_held = false
        st.attack_held = false
        st.b_held = false
        st.mask = 0
        have_prev = false
        return
    end

    st.ok = true
    st.mask = mask
    st.l2_held = has_bit(mask, BIT_L2)
    st.x_held = has_bit(mask, BIT_X)
    st.a_held = has_bit(mask, BIT_A)
    st.xa_held = st.x_held and st.a_held
    st.attack_held = st.x_held or st.a_held
    st.b_held = has_bit(mask, BIT_B)
    st.dir = mask_to_dir(mask)

    if have_prev then
        local function bit_trg(bit)
            return has_bit(mask, bit) and not has_bit(prev_mask, bit)
        end
        local prev_attack = has_bit(prev_mask, BIT_X) or has_bit(prev_mask, BIT_A)

        st.l2_trg = bit_trg(BIT_L2)
        st.l2_rel = has_bit(prev_mask, BIT_L2) and not st.l2_held
        st.r2_trg = bit_trg(BIT_R2)
        st.l1_trg = bit_trg(BIT_L1)
        st.r1_trg = bit_trg(BIT_R1)
        st.attack_trg = st.attack_held and not prev_attack
        st.b_trg = bit_trg(BIT_B)
    end

    prev_mask = mask
    have_prev = true
end

function pad.state()
    return st
end

function pad.is_ready()
    return st.ok
end

function pad.has(bit)
    return has_bit(st.mask, bit)
end

function pad.dir()
    return st.dir
end

function pad.dir_bits()
    return {
        front = has_bit(st.mask, BIT_ELU) or has_bit(st.mask, BIT_CC),
        back  = has_bit(st.mask, BIT_ELD),
        left  = has_bit(st.mask, BIT_ELL),
        right = has_bit(st.mask, BIT_ELR),
    }
end

function pad.stick_dir(deadzone)
    return st.dir or "front"
end

function pad.dump()
    local now = game.time()

    log.info("──────── HornResonance 手把狀態 ────────")
    local s = get_singleton()
    log.info("  snow.Pad singleton : " .. (s and "OK" or "讀不到"))

    local dev = get_device(now)
    log.info("  使用的裝置欄位     : " .. device_field .. (dev and "（OK）" or "（讀不到）"))

    if not dev then
        log.info("  → 請先進入遊戲（讀取畫面之後才會有手把物件）")
        log.info("─────────────────────────────────────")
        return
    end

    local mask = read_mask(dev)
    if mask == nil then
        log.info("  讀不到按鍵遮罩（get_on 與 OrTrg 都失敗）")
        log.info("─────────────────────────────────────")
        return
    end

    local function has(bit)
        return has_bit(mask, bit)
    end

    local x, a = has(BIT_X), has(BIT_A)
    local decide = has(BIT_DECIDE)

    log.info(string.format("  按鍵遮罩           : 0x%08X", mask))
    log.info("  L1      (0x100)    : " .. tostring(has(BIT_L1)))
    log.info("  L2 / ZL (0x200)    : " .. tostring(has(BIT_L2)) .. "   ← 接技用的鍵")
    log.info("  R1      (0x400)    : " .. tostring(has(BIT_R1)))
    log.info("  R2 / ZR (0x800)    : " .. tostring(has(BIT_R2)))
    log.info("  X       (0x00000010) : " .. tostring(x))
    log.info("  A       (0x00020080) : " .. tostring(a) .. "   ← 用 0x80 位元判斷")
    log.info("  X+A     (0x00020090) : " .. tostring(x and a))
    log.info("  B       (0x00000020) : " .. tostring(has(BIT_B)) .. "   ← 翻滾取消用的鍵")
    log.info("  Decide  (0x00020000) : " .. tostring(decide) .. "（A 通常會帶）")

    local db = {
        front = has(BIT_ELU) or has(BIT_CC),
        back  = has(BIT_ELD),
        left  = has(BIT_ELL),
        right = has(BIT_ELR),
    }
    local function mark(v) return v and "●" or "○" end
    log.info(string.format("  左搖桿方向         : 前%s 後%s 左%s 右%s  → 判定 %s",
        mark(db.front), mark(db.back), mark(db.left), mark(db.right),
        pad.stick_dir()))
    log.info("  ELU(前)=0x00100000  ELR(右)=0x00200000  ELD(後)=0x00400000  ELL(左)=0x00800000")
    log.info("  CC (前，備援)=0x00010000")
    log.info("  → 推左搖桿時上面四個圓圈應該有一個變成 ●；都沒有 = 往前滾")
    log.info("  → 按住 ZL 再按一次這顆按鈕，上面 L2 / ZL 應該變成 true")
    log.info("  → 按 X / A 時，上面對應那行應該變成 true（派生學習靠這個）")
    log.info("─────────────────────────────────────")
end
function pad.reset()
    prev_mask = 0
    have_prev = false
    st.ok = false
    st.l2_held = false
    st.x_held = false
    st.a_held = false
    st.xa_held = false
    st.attack_held = false
    st.b_held = false
    st.b_trg = false
    st.dir = nil
    st.mask = 0
end

return pad
