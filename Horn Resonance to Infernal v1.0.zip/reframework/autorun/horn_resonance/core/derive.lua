local derive = {}

local config = require("horn_resonance/core/config")
local game = require("horn_resonance/core/game")
local seed = require("horn_resonance/core/seed")

local FILE_NAME = "horn_resonance_derive.json"
local MIN_FRAME = 6.0
local EARLY_RATIO = 0.08
local BIG_DROP = 0.50
local BIG_DROP_NEED = 4
local SEED_HEAL = 0.50
local SAVE_DELAY = 2.0

local derives = nil
local lengths = nil

local dirty = false
local dirty_at = -1000.0

local stats = {
    observations = 0,
    accepted = 0,
    reject_self = 0,
    reject_from = 0,
    reject_to = 0,
    reject_input = 0,
    reject_early = 0,
    reject_same = 0,
    lengths_learned = 0,
}

local function collect_mode()
    return config.get("derive_collect_enabled") == true
end

local function learn_mode()
    return config.get("derive_learn_enabled") == true
end

local function apply_seed()
    local added_d, added_l, lowered, healed = 0, 0, 0, 0

    for _, s in ipairs(seed.derives) do
        local from = math.floor(s.from)
        if from > 0 and s.frame and s.frame >= MIN_FRAME then
            local e = derives[from]
            if not e then
                derives[from] = { frame = s.frame, to = s.to or 0, hits = 0 }
                added_d = added_d + 1
            elseif s.frame < e.frame then
                e.frame = s.frame
                e.to = s.to or e.to
                lowered = lowered + 1
            elseif e.frame < s.frame * SEED_HEAL then

                log.info(string.format(
                    "[HornResonance/derive] 取消點自癒：action %d 的存檔值 %.1f 幀太早（內建 %.0f 幀）→ 還原",
                    from, e.frame, s.frame))
                e.frame = s.frame
                e.to = s.to or e.to
                e.early = 0
                healed = healed + 1
            end
        end

        if s.len and s.len >= MIN_FRAME then
            local old = lengths[from]
            if not old then
                lengths[from] = s.len
                added_l = added_l + 1
            elseif s.len > old then
                lengths[from] = s.len
            end
        end
    end

    if added_d > 0 or lowered > 0 or added_l > 0 or healed > 0 then
        log.info(string.format(
            "[HornResonance/derive] 套用內建取消點：新增 %d 筆、修正為更早 %d 筆、補動作長度 %d 筆、雜訊還原 %d 筆",
            added_d, lowered, added_l, healed))
    end
end

local function too_early(from, frame)
    if frame < MIN_FRAME then
        return string.format("below_min(%.1f)", MIN_FRAME)
    end
    local len = lengths[from]
    if len and len >= 10.0 and frame < len * EARLY_RATIO then
        return string.format("under_%d%%_of_len", math.floor(EARLY_RATIO * 100))
    end
    return nil
end

local function log_table()
    local keys = {}
    for from in pairs(derives) do table.insert(keys, from) end
    table.sort(keys)

    local parts = {}
    for _, from in ipairs(keys) do
        local e = derives[from]
        local len = lengths[from]
        local fr = (e.frame % 1 == 0) and string.format("%d", e.frame) or string.format("%.1f", e.frame)
        table.insert(parts, string.format("%d=%s%s%s",
            from, fr,
            len and string.format("/%.0f", len) or "",
            (e.hits == 0) and "*" or ""))
    end

    if #parts == 0 then
        log.info("[HornResonance/derive] 取消點表：空")
        return
    end
    log.info("[HornResonance/derive] 取消點表（動作=取消點/長度，* = 內建種子）：")
    log.info("  " .. table.concat(parts, "  "))
end

local function load()
    if derives then return end
    derives = {}
    lengths = {}

    local loaded = json.load_file(FILE_NAME)
    if type(loaded) == "table" then
        if type(loaded.derives) == "table" then
            for _, e in ipairs(loaded.derives) do
                if type(e) == "table" and type(e.from) == "number" and type(e.frame) == "number" then
                    local from = math.floor(e.from)
                    if from > 0 and e.frame >= MIN_FRAME then
                        derives[from] = {
                            frame = e.frame,
                            to = type(e.to) == "number" and math.floor(e.to) or 0,
                            hits = type(e.hits) == "number" and math.floor(e.hits) or 1,
                            early = type(e.early) == "number" and math.floor(e.early) or 0,
                        }
                    end
                end
            end
        end

        if type(loaded.lengths) == "table" then
            for _, e in ipairs(loaded.lengths) do
                if type(e) == "table" and type(e.action) == "number" and type(e.len) == "number" then
                    local a = math.floor(e.action)
                    if a > 0 and e.len >= MIN_FRAME then lengths[a] = e.len end
                end
            end
        end
    end

    apply_seed()

    log.info(string.format(
        "[HornResonance/derive] 讀取學習資料：派生點 %d 筆、動作長度 %d 筆",
        derive.count(), derive.length_count()))
    log_table()
end

local function mark_dirty()
    dirty = true
    dirty_at = game.time()
end

local function save()
    local list_d, list_l = {}, {}
    for from, e in pairs(derives) do
        table.insert(list_d, { from = from, to = e.to, frame = e.frame, hits = e.hits, early = e.early or 0 })
    end
    for a, len in pairs(lengths) do
        table.insert(list_l, { action = a, len = len })
    end

    table.sort(list_d, function(x, y) return x.from < y.from end)
    table.sort(list_l, function(x, y) return x.action < y.action end)

    json.dump_file(FILE_NAME, { version = 2, derives = list_d, lengths = list_l })
    dirty = false
end

function derive.observe_derive(o)
    load()
    stats.observations = stats.observations + 1

    local from = math.floor(o.from or 0)
    local to = math.floor(o.to or 0)
    local frame = o.frame or 0.0

    local reason = nil
    if o.self_jump then
        reason = "self_jump"
        stats.reject_self = stats.reject_self + 1
    elseif from <= 0 then
        reason = "from_invalid"
        stats.reject_from = stats.reject_from + 1
    elseif to <= 0 then
        reason = "to_invalid"
        stats.reject_to = stats.reject_to + 1
    elseif from == to and not o.allow_same then
        reason = "same_action"
        stats.reject_same = stats.reject_same + 1
    elseif not o.from_was_attack then
        reason = "from_not_attack"
        stats.reject_from = stats.reject_from + 1
    elseif not o.to_is_attack then
        reason = "to_not_attack"
        stats.reject_to = stats.reject_to + 1
    elseif not o.atk then
        reason = "no_attack_input"
        stats.reject_input = stats.reject_input + 1
    else
        local why = too_early(from, frame)
        if why then
            reason = "too_early:" .. why
            stats.reject_early = stats.reject_early + 1
        end
    end

    if reason then
        if collect_mode() then
            log.info(string.format(
                "[LEARN-REJECT] A=%d -> B=%d frame=%.0f mask=0x%08X reason=%s",
                from, to, frame, o.mask or 0, reason))
        end
        return false
    end

    if not learn_mode() then
        if collect_mode() then
            log.info(string.format(
                "[LEARN-OFF] A=%d -> B=%d frame=%.0f（自動學習已關閉，未寫入）",
                from, to, frame))
        end
        return false
    end

    stats.accepted = stats.accepted + 1

    local e = derives[from]
    local improved = false
    local first = false
    local confirmed_seed = false
    local deferred = false
    if not e then
        derives[from] = { frame = frame, to = to, hits = 1, early = 0 }
        improved = true
        first = true
    else
        if e.hits == 0 then confirmed_seed = true end
        e.hits = e.hits + 1
        e.to = to
        if frame < e.frame then

            if frame >= e.frame * (1.0 - BIG_DROP) then
                e.frame = frame
                e.early = 0
                improved = true
            else
                e.early = (e.early or 0) + 1
                if e.early >= BIG_DROP_NEED then
                    log.info(string.format(
                        "[HornResonance/derive] 大幅提前的取消點經 %d 次連續確認：action %d 由 %.0f 幀改為 %.0f 幀",
                        e.early, from, e.frame, frame))
                    e.frame = frame
                    e.early = 0
                    improved = true
                else
                    deferred = true
                end
            end
        else

            e.early = 0
        end
    end

    if deferred and not improved then
        if collect_mode() then
            log.info(string.format(
                "[LEARN-DEFER] A=%d frame=%.0f 比現值 %.0f 早太多，等第 %d 次確認（目前 %d）",
                from, frame, derives[from].frame, BIG_DROP_NEED, derives[from].early or 0))
        end
        return false
    end

    if improved or confirmed_seed then mark_dirty() end

    local cur = derives[from]

    if collect_mode() then
        log.info(string.format(
            "[LEARN] A=%d -> B=%d frame=%.0f mask=0x%08X atk=1 => 採用 %.0f（hits %d%s%s）",
            from, to, frame, o.mask or 0, cur.frame, cur.hits,
            first and "，新動作" or "", (from == to) and "，同動作重觸發" or ""))
    elseif improved then
        if not learn_mode() then

            return true
        end
        log.info(string.format(
            "[HornResonance/derive] 學到派生取消點：action %d 在第 %.0f 幀可派生（→ %d，hits %d）",
            from, cur.frame, to, cur.hits))
    elseif confirmed_seed and learn_mode() then
        log.info(string.format(
            "[HornResonance/derive] 內建取消點經實測確認：action %d = %.0f 幀（本次觀測 %.0f）",
            from, cur.frame, frame))
    end

    return true
end

function derive.observe_length(action, len)
    load()
    local a = math.floor(action or 0)
    if a <= 0 or type(len) ~= "number" or len < MIN_FRAME then return end

    if not learn_mode() then
        if collect_mode() then
            log.info(string.format("[LEN-OFF] A=%d len=%.0f（自動學習已關閉，未寫入）", a, len))
        end
        return
    end

    local old = lengths[a]
    if old and len <= old then return end

    lengths[a] = len
    stats.lengths_learned = stats.lengths_learned + 1
    mark_dirty()

    if collect_mode() or learn_mode() then
        log.info(string.format("[LEN] A=%d len=%.0f", a, len))
    end
end

function derive.get_derive(action)
    load()
    local e = derives[math.floor(action or 0)]
    if not e then return nil end
    return e.frame
end

function derive.get_derive_entry(action)
    load()
    return derives[math.floor(action or 0)]
end

function derive.get_length(action)
    load()
    return lengths[math.floor(action or 0)]
end

function derive.count()
    load()
    local n = 0
    for _ in pairs(derives) do n = n + 1 end
    return n
end

function derive.length_count()
    load()
    local n = 0
    for _ in pairs(lengths) do n = n + 1 end
    return n
end

function derive.stats()
    return stats
end

function derive.tick(now)
    if not dirty then return end
    if (now - dirty_at) < SAVE_DELAY then return end
    save()
end

function derive.dump()
    load()
    log.info("════════ HornResonance 派生取消點學習表 ════════")

    local list = {}
    for from, e in pairs(derives) do
        table.insert(list, { from = from, e = e })
    end
    table.sort(list, function(x, y) return x.from < y.from end)

    if #list == 0 then
        log.info("  （還沒有任何資料，先正常打幾下就會自己學到）")
    else
        local seeded = 0
        log.info(string.format("  共 %d 個動作：", #list))
        for _, it in ipairs(list) do
            local len = lengths[it.from]

            local tag = (it.e.hits == 0) and "[SEED]" or "[LEARN]"
            if it.e.hits == 0 then seeded = seeded + 1 end
            log.info(string.format("    %s A=%d -> B=%d frame=%.0f hits=%d%s",
                tag, it.from, it.e.to, it.e.frame, it.e.hits,
                len and string.format(" len=%.0f", len) or ""))
        end
        if seeded > 0 then
            log.info(string.format("  其中 %d 筆來自內建種子（尚未經本人實測確認）", seeded))
        end
    end

    local only_len = {}
    for a, len in pairs(lengths) do
        if not derives[a] then table.insert(only_len, { a = a, len = len }) end
    end
    if #only_len > 0 then
        table.sort(only_len, function(x, y) return x.a < y.a end)
        log.info(string.format("  只有長度、沒有派生點：%d 個", #only_len))
        for _, it in ipairs(only_len) do
            log.info(string.format("    [LEN] A=%d len=%.0f", it.a, it.len))
        end
    end

    log.info(string.format(
        "  觀測 %d / 採用 %d ｜ 否決：自己跳 %d、來源非攻擊 %d、目標非攻擊 %d、沒按鍵 %d、太前面 %d、同動作 %d",
        stats.observations, stats.accepted, stats.reject_self, stats.reject_from,
        stats.reject_to, stats.reject_input, stats.reject_early, stats.reject_same))
    log.info("════════════════════════════════════════════════")
end

function derive.reset()
    load()
    derives = {}
    lengths = {}
    stats.accepted = 0
    stats.observations = 0
    stats.lengths_learned = 0

    apply_seed()
    mark_dirty()
    save()
    log.info("[HornResonance/derive] 已清空個人學習資料，並重新套用內建取消點")
end

return derive
