local settings = {}

local game = require("horn_resonance/core/game")
local config = require("horn_resonance/core/config")
local wirebug = require("horn_resonance/core/wirebug")
local l2_combo = require("horn_resonance/core/l2_combo")
local pad = require("horn_resonance/core/pad")
local derive = require("horn_resonance/core/derive")
local rules = require("horn_resonance/core/rules")
local iframe = require("horn_resonance/core/iframe")
local evade_cancel = require("horn_resonance/core/evade_cancel")
local hellfire = require("horn_resonance/core/hellfire")

local recorder_open = false
local infernal_hex_buffer = ""
local blocked_buffer = ""
local override_buffer = ""
local iframe_actions_buffer = ""
local iframe_native_buffer = ""
local hellfire_actions_buffer = ""

local function refresh_buffers()
    if infernal_hex_buffer == "" then
        local node = config.get("infernal_node")
        infernal_hex_buffer = (node == 0 or node == nil) and "" or string.format("%08X", node)
    end
    if blocked_buffer == "" then
        blocked_buffer = tostring(config.get("l2_blocked_actions") or "")
    end
    if override_buffer == "" then
        override_buffer = tostring(config.get("l2_override_frames") or "")
    end
    if iframe_actions_buffer == "" then
        iframe_actions_buffer = tostring(config.get("iframe_actions") or "")
    end
    if iframe_native_buffer == "" then
        iframe_native_buffer = tostring(config.get("iframe_evade_actions") or "")
    end
    if hellfire_actions_buffer == "" then
        hellfire_actions_buffer = tostring(config.get("hellfire_shake_actions") or "")
    end
end

local function capture_infernal()
    local node = game.get_current_node()
    if not node or node == 0 then
        log.warn("[HornResonance] 目前節點為 0，無法記錄（請在氣焰旋律動作進行中按下）")
        return
    end
    config.set("infernal_node", node)
    infernal_hex_buffer = string.format("%08X", node)
    log.info(string.format("[HornResonance] 已記錄 氣焰旋律 node=0x%08X action=%d",
        node, game.get_action_id()))
end

local function apply_infernal_hex(buffer)
    local value = tonumber(buffer, 16)
    if value then
        config.set("infernal_node", value)
        log.info(string.format("[HornResonance] 氣焰旋律節點手動設定為 0x%08X", value))
    else
        log.warn("[HornResonance] 無法解析十六進位：" .. tostring(buffer))
    end
end

local function draw_combo_tree()
    if not imgui.tree_node("L2 輕點接技（氣焰旋律）") then return end

    local changed, value

    changed, value = imgui.checkbox("啟用 L2 輕點接技", config.get("l2_combo_enabled"))
    if changed then config.set("l2_combo_enabled", value) end

    imgui.text_colored("一般攻擊中輕點 L2 → 直接接氣焰旋律（不耗翔蟲）", 0.6, 0.9, 1.0, 1.0)

    changed, value = imgui.slider_float("輕點判定時間（秒）", config.get("l2_tap_window"), 0.10, 0.60, "%.2f")
    if changed then config.set("l2_tap_window", value) end

    changed, value = imgui.slider_int("黏著幀數", config.get("l2_sticky_frames"), 0, 15)
    if changed then config.set("l2_sticky_frames", value) end

    changed, value = imgui.slider_float("接技冷卻（秒）", config.get("l2_cooldown"), 0.0, 3.0, "%.2f")
    if changed then config.set("l2_cooldown", value) end

    changed, value = imgui.checkbox("限定一般攻擊中", config.get("l2_require_attack"))
    if changed then config.set("l2_require_attack", value) end

    imgui.separator()
    imgui.text("接技時機")

    changed, value = imgui.checkbox("等可以取消才接（不砍動畫）", config.get("l2_queue_enabled"))
    if changed then config.set("l2_queue_enabled", value) end

    changed, value = imgui.checkbox("用學到的派生取消點", config.get("l2_use_derive"))
    if changed then config.set("l2_use_derive", value) end
    imgui.text_colored("派生點 = 玩家按 X/A 接下一段的同一幀，最準", 0.7, 0.7, 0.7, 1.0)

    changed, value = imgui.slider_float("比例退路（0 = 關閉）", config.get("l2_cancel_ratio"), 0.0, 1.0, "%.2f")
    if changed then config.set("l2_cancel_ratio", value) end
    imgui.text_colored("沒學到派生點時才用：動作總長 × 比例；0 就等攻擊自然結束", 0.7, 0.7, 0.7, 1.0)

    changed, value = imgui.slider_float("等待逾時（秒）", config.get("l2_queue_timeout"), 0.5, 6.0, "%.1f")
    if changed then config.set("l2_queue_timeout", value) end

    imgui.separator()

    local dbg = l2_combo.get_debug_info()
    if dbg.blocked then
        imgui.text_colored(string.format("本動作: action %d   幀 %.0f   ⛔ 已設定禁止 ZL 取消",
            dbg.action, dbg.frame), 1.0, 0.55, 0.45, 1.0)
    elseif dbg.source == "override" then
        if dbg.frame and dbg.override and dbg.frame >= dbg.override then
            imgui.text_colored(string.format("本動作: action %d   幀 %.0f   手動取消點 %.0f   → 可以接了",
                dbg.action, dbg.frame, dbg.override), 0.5, 0.95, 1.0, 1.0)
        else
            imgui.text(string.format("本動作: action %d   幀 %.0f   手動取消點 %.0f（還要 %.0f 幀）",
                dbg.action, dbg.frame, dbg.override,
                (dbg.override or 0) - (dbg.frame or 0)))
        end
        if not dbg.is_attack then
            imgui.text_colored("（演奏類沒有 Attack 標籤，v2.3.11 起手動取消點不受此限制）",
                0.6, 0.8, 0.9, 1.0)
        end
    elseif dbg.derive then
        imgui.text(string.format("本動作: action %d   幀 %.0f   派生點 %.0f   → 可以接了",
            dbg.action, dbg.frame, dbg.derive))
    elseif dbg.need then
        imgui.text(string.format("本動作: action %d   幀 %.0f   比例取消點 %.0f",
            dbg.action, dbg.frame, dbg.need))
    else
        imgui.text(string.format("本動作: action %d   幀 %.0f   尚無取消點（會等攻擊結束）",
            dbg.action, dbg.frame))
    end
    if dbg.override and dbg.length and dbg.override > dbg.length then
        imgui.text_colored(string.format(
            "⚠ 手動取消點 %.0f 超過動作總長 %.0f → 實際會等攻擊結束才接",
            dbg.override, dbg.length), 1.0, 0.6, 0.3, 1.0)
    end
    imgui.text(string.format("已學習派生點: %d 個動作（含內建種子）", dbg.learned_count))
    if dbg.action0_window then
        imgui.text_colored("action 0 空窗中（下揮後段）→ 整段都可被 L2 取消", 0.5, 0.95, 1.0, 1.0)
    else
        imgui.text_colored(string.format("action 0 空窗：否（目前 action %d / bank %d）",
            dbg.action, dbg.bank or 0), 0.6, 0.6, 0.6, 1.0)
    end

    local since_hit = dbg.since_hit or 999.0
    local grace = dbg.hit_grace or 1.2
    if since_hit < grace then
        imgui.text_colored(string.format(
            "受擊保護中（%.2f / %.1f 秒）→ ZL+B 讓給翔蟲受身，不接技",
            since_hit, grace), 1.0, 0.6, 0.35, 1.0)
    else
        imgui.text_colored(string.format("距上次受擊 %.1f 秒（保護 %.1f 秒）", since_hit, grace),
            0.6, 0.6, 0.6, 1.0)
    end
    if not dbg.is_weapon_action then
        imgui.text_colored(string.format("非武器動作（bank %d）→ 不搶按鍵", dbg.bank or 0),
            0.7, 0.7, 0.7, 1.0)
    end

    local pi = l2_combo.get_pending_info()
    if pi then
        imgui.text_colored(string.format("佇列：等待取消點…（action %d，已等 %.2f 秒）",
            pi.action, pi.waited), 1.0, 0.85, 0.3, 1.0)
    else
        imgui.text_colored("佇列：空", 0.7, 0.7, 0.7, 1.0)
    end

    imgui.separator()

    local stats = l2_combo.get_stats()
    imgui.text(string.format("輕點 %d / 觸發 %d / 條件不符 %d / 忽略 %d",
        stats.taps, stats.triggers, stats.rejected, stats.ignored))
    imgui.text(string.format("觸發來源：派生點 %d / 手動 %d / 比例 %d / 攻擊結束 %d / action0 %d",
        stats.by_derive, stats.by_override, stats.by_ratio, stats.by_end,
        stats.by_action0 or 0))
    imgui.text(string.format("排入佇列 %d / 逾時丟棄 %d", stats.queued, stats.dropped))
    imgui.text("最近結果: " .. tostring(stats.last_reason))

    local st = pad.state()
    if st.ok then
        imgui.text(string.format("手把: 正常   遮罩 0x%08X   L2/ZL %s   B %s   X %s   A %s",
            st.mask, tostring(st.l2_held), tostring(st.b_held),
            tostring(st.x_held), tostring(st.a_held)))
    else
        imgui.text_colored("手把: 讀不到（請先進入遊戲）", 1.0, 0.7, 0.3, 1.0)
    end

    if game.is_attack() then
        imgui.text_colored("攻擊中: true（可接技）", 0.4, 1.0, 0.4, 1.0)
    else
        imgui.text_colored("攻擊中: false（此時輕點 L2 不會觸發）", 0.7, 0.7, 0.7, 1.0)
    end

    local cnt = wirebug.get_count()
    imgui.text("翔蟲: " .. (cnt and tostring(cnt) or "—") .. "（只讀，僅用來判斷是否為輕點）")

    imgui.separator()
    imgui.text("氣焰旋律識別碼: " .. config.infernal_node_text())
    changed, infernal_hex_buffer = imgui.input_text("氣焰旋律 識別碼（進階，遊戲改版後才需調整）", infernal_hex_buffer)
    if changed then apply_infernal_hex(infernal_hex_buffer) end
    if imgui.button("在動作中記錄為【氣焰旋律】") then capture_infernal() end

    imgui.separator()
    if imgui.button("手把狀態診斷（輸出到日誌）") then pad.dump() end
    imgui.same_line()
    if imgui.button("接技診斷（輸出到日誌）") then l2_combo.dump_state() end
    if imgui.button("action 0 診斷（記錄 10 秒）") then l2_combo.trace_action0(10.0) end
    if l2_combo.is_tracing() then
        imgui.same_line()
        imgui.text_colored("記錄中…請出一次下揮", 1.0, 0.85, 0.3, 1.0)
    else
        imgui.text_colored("按下後 10 秒內，每次 (action / bank / 攻擊中) 變化都會寫一行 trace 到日誌",
            0.7, 0.7, 0.7, 1.0)
    end

    imgui.tree_pop()
end

local function draw_rules_tree()
    if not imgui.tree_node("手動規則（禁止取消 / 指定取消點）") then return end

    local changed, value

    changed, value = imgui.checkbox("啟用（預設開）", config.get("l2_override_enabled"))
    if changed then config.set("l2_override_enabled", value) end
    imgui.text_colored("手動規則的優先序高於學習到的派生點", 0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    changed, blocked_buffer = imgui.input_text("禁止取消的動作（逗號分隔）", blocked_buffer)
    if changed then config.set("l2_blocked_actions", blocked_buffer) end
    imgui.text_colored("預設：兩種演奏起手與鐵蟲絲響打起手不讓 ZL 打斷",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    changed, override_buffer = imgui.input_text("指定取消點 動作:幀數（逗號分隔）", override_buffer)
    if changed then config.set("l2_override_frames", override_buffer) end
    imgui.text_colored("預設：三音演奏與兩種演奏 180 幀後可取消",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    imgui.text("目前生效：" .. rules.summary())

    imgui.tree_pop()
end

local function draw_iframe_tree()
    if not imgui.tree_node("迴避判定（無敵幀 / 迴避成功）") then return end

    local changed, value

    changed, value = imgui.checkbox("啟用無敵幀（預設開）", config.get("iframe_enabled"))
    if changed then config.set("iframe_enabled", value) end
    imgui.text_colored("窗口內 checkCalcDamage_DamageSide 回 NoExecute_SaveHitID（整段閃掉）",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    changed, iframe_actions_buffer = imgui.input_text("無敵動作（逗號分隔）", iframe_actions_buffer)
    if changed then config.set("iframe_actions", iframe_actions_buffer) end
    imgui.text_colored("預設 160,161,167,168,169", 0.7, 0.7, 0.7, 1.0)

    changed, value = imgui.slider_int("無敵幀數（動作幀）", config.get("iframe_frames"), 0, 120)
    if changed then config.set("iframe_frames", value) end
    imgui.text_colored("算的是「動作自己的幀數」：動作播到第 N 幀為止都無敵（預設 30 幀 ≈ 半秒）",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    changed, value = imgui.checkbox("啟用迴避成功判定（預設開）", config.get("iframe_evade_enabled"))
    if changed then config.set("iframe_evade_enabled", value) end
    imgui.text_colored("讓這些無敵幀被遊戲算成「迴避成功」，會觸發迴避系技能",
        0.7, 0.7, 0.7, 1.0)

    changed, iframe_native_buffer = imgui.input_text("原生無敵補迴避（逗號分隔）", iframe_native_buffer)
    if changed then config.set("iframe_evade_actions", iframe_native_buffer) end
    imgui.text_colored("預設：這一招本來就有無敵幀但沒有迴避判定，這裡補上",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    local info = iframe.get_info()
    local tag = ""
    if info.is_target then tag = tag .. "（無敵清單）" end
    if info.is_evade_target then tag = tag .. "（原生迴避清單）" end
    if tag ~= "" then
        imgui.text_colored(string.format("本動作: action %d %s", info.action, tag),
            0.5, 0.95, 1.0, 1.0)
    else
        imgui.text(string.format("本動作: action %d", info.action))
    end

    if info.window_open then
        imgui.text_colored(string.format("窗口: 開（動作幀數 %.1f / %d）",
            info.motion_frame, info.frames), 1.0, 0.85, 0.3, 1.0)
    else
        imgui.text_colored(string.format("窗口: 關（動作幀數 %.1f / %d）",
            info.motion_frame, info.frames), 0.7, 0.7, 0.7, 1.0)
    end

    if info.motion_frozen then
        imgui.text_colored("動作幀數: 已停住（視為動作結束）", 0.7, 0.7, 0.7, 1.0)
    end

    imgui.text("原生無敵中: " .. tostring(info.native_muteki)
        .. "   迴避判定: " .. (info.evade_check and "開" or "關"))
    imgui.text(string.format("開窗 %d / 擋下傷害 %d / 補發迴避成功 %d",
        info.windows, info.blocked_damage, info.escape_calls))
    imgui.text(string.format("未攔截受擊 %d / 遊戲回呼迴避成功 %d（原始路徑）",
        info.missed_hits, info.escape_hits))

    local skill = iframe.get_skill_state()
    if skill then
        imgui.text("迴避系技能: " .. skill)
        imgui.text_colored("timer 在補發後有變大 = 技能真的吃到了；一直是 0 = 沒裝技能或沒吃到",
            0.7, 0.7, 0.7, 1.0)
    end

    imgui.text_colored("「擋下傷害」有跳 = 無敵生效；「補發迴避成功」有跳 = 技能會觸發",
        0.7, 0.7, 0.7, 1.0)
    imgui.text(string.format("診斷: checkMuteki %d 次 / 傷害判定 %d 次",
        info.muteki_calls, info.damage_calls))

    imgui.separator()
    if imgui.button("迴避判定診斷（輸出到日誌）") then iframe.dump() end

    imgui.tree_pop()
end

local function draw_evade_cancel_tree()
    if not imgui.tree_node("氣焰旋律：戳地板後翻滾取消") then return end

    local changed, value

    changed, value = imgui.checkbox("啟用翻滾取消（預設開）", config.get("evade_cancel_enabled"))
    if changed then config.set("evade_cancel_enabled", value) end
    imgui.text_colored("戳地板之後按 B → 直接翻滾取消後搖（走原生翻滾動作，含迴避判定）",
        0.7, 0.7, 0.7, 1.0)
    imgui.text_colored("v2.3.10：受擊 / 倒地 / 受身時完全不搶 B，翔蟲受身（ZL+B）不會被吃掉",
        0.6, 0.85, 1.0, 1.0)

    imgui.separator()
    imgui.text("第二段：緊急迴避窗口（動作最前面）")

    changed, value = imgui.checkbox("啟用緊急迴避（預設開）", config.get("evade_cancel_early_enabled"))
    if changed then config.set("evade_cancel_early_enabled", value) end

    changed, value = imgui.slider_int("緊急迴避起始幀",
        config.get("evade_cancel_early_min"), 0, 120)
    if changed then config.set("evade_cancel_early_min", value) end

    changed, value = imgui.slider_int("緊急迴避結束幀",
        config.get("evade_cancel_early_frames"), 0, 120)
    if changed then config.set("evade_cancel_early_frames", value) end
    imgui.text_colored(string.format("窗口 = %d ~ %d 幀；滾掉 = 放棄這一發（沒有傷害、沒有 buff）",
        config.get("evade_cancel_early_min") or 0,
        config.get("evade_cancel_early_frames") or 0), 0.7, 0.7, 0.7, 1.0)
    if (config.get("evade_cancel_early_min") or 0) >= (config.get("evade_cancel_early_frames") or 0) then
        imgui.text_colored("⚠ 起始幀沒有小於結束幀，這個窗口不會生效", 1.0, 0.55, 0.45, 1.0)
    end

    imgui.separator()
    imgui.text("第一段：取消後搖")

    changed, value = imgui.slider_int("可取消的動作幀", config.get("evade_cancel_frame"), 0, 203)
    if changed then config.set("evade_cancel_frame", value) end
    if (config.get("evade_cancel_frame") or 0) < 110 then
        imgui.text_colored("⚠ 低於 110 會讓旋律 buff 那一步不執行（有動作、有傷害，但沒 buff）",
            1.0, 0.55, 0.45, 1.0)
    else
        imgui.text_colored("動作全長 203 幀；110 幀設旋律 buff、60 幀出音爆",
            0.7, 0.7, 0.7, 1.0)
    end
    if (config.get("evade_cancel_frame") or 0) <= (config.get("evade_cancel_early_frames") or 0) then
        imgui.text_colored("⚠ 後搖門檻沒有大於緊急迴避結束幀，兩段窗口會黏在一起",
            1.0, 0.55, 0.45, 1.0)
    end

    changed, value = imgui.slider_int("切換後黏著幀數", config.get("evade_cancel_sticky"), 0, 15)
    if changed then config.set("evade_cancel_sticky", value) end
    imgui.text_colored("避免氣焰旋律的動作下一幀又把翻滾搶回去", 0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    imgui.text("翻滾方向（v2.3.13 起，v2.3.14 改用 EL* 位元）")

    changed, value = imgui.checkbox("依左搖桿決定方向（預設開）",
        config.get("evade_cancel_direction") ~= false)
    if changed then config.set("evade_cancel_direction", value) end
    imgui.text_colored("關閉 = 不管推哪裡都往前滾（v2.3.12 的行為）", 0.7, 0.7, 0.7, 1.0)

    local einfo = evade_cancel.get_info()
    local dir_cn = ({ front = "往前", left = "往左", right = "往右", back = "往後" })[einfo.dir]
        or tostring(einfo.dir)
    local db = einfo.dir_bits
    local function mark(v) return v and "●" or "○" end
    imgui.text(string.format("方向位元：前%s 後%s 左%s 右%s → %s",
        mark(db.front), mark(db.back), mark(db.left), mark(db.right), dir_cn))
    if not einfo.has_dir then
        imgui.text_colored("沒推方向 → 往前滾", 0.7, 0.7, 0.7, 1.0)
    end
    imgui.text_colored("推左搖桿時應該有一個圓圈變成 ●；都沒有 = 往前滾",
        0.65, 0.75, 0.85, 1.0)
    imgui.text_colored("ELU(前) 0x00100000 / ELR(右) 0x00200000 / ELD(後) 0x00400000 / ELL(左) 0x00800000",
        0.6, 0.6, 0.6, 1.0)

    imgui.separator()

    local info = evade_cancel.get_info()
    if info.in_infernal then
        imgui.text_colored(string.format("氣焰旋律中：動作幀 %.1f", info.frame), 1.0, 0.85, 0.3, 1.0)
        if info.early_enabled and info.frame >= info.early_min and info.frame <= info.early then
            imgui.text_colored(string.format("→ 緊急迴避窗口（%d~%d）：按 B 會放棄這一發",
                info.early_min, info.early), 1.0, 0.65, 0.35, 1.0)
        elseif info.frame >= info.need then
            imgui.text_colored("→ 取消後搖窗口：按 B 可以翻滾取消（buff 已生效）",
                0.4, 1.0, 0.4, 1.0)
        else
            imgui.text_colored(string.format("→ 等 buff 禁區（還要 %.0f 幀才到 %d）",
                info.need - info.frame, info.need), 0.7, 0.7, 0.7, 1.0)
        end
    else
        imgui.text_colored("目前不在氣焰旋律動作中", 0.7, 0.7, 0.7, 1.0)
    end

    imgui.text(string.format("取消後搖 %d / 緊急迴避 %d / 等 buff %d / 冷卻 %d / 失敗 %d",
        info.triggers, info.early_triggers, info.too_early, info.blocked, info.fail))
    imgui.text(string.format("方向統計：前 %d / 左 %d / 右 %d / 後 %d（最後一次：%s）",
        info.by_dir.front or 0, info.by_dir.left or 0,
        info.by_dir.right or 0, info.by_dir.back or 0,
        ({ front = "往前", left = "往左", right = "往右", back = "往後" })[info.last_dir]
            or tostring(info.last_dir)))
    imgui.text(string.format("讓給翔蟲受身：非武器動作 %d / 受擊後 %d 次",
        info.wrong_bank or 0, info.hit_blocked or 0))
    imgui.text(string.format("最後一次按 B 的動作幀：%.1f（調門檻就看這個）", info.last_frame))
    imgui.text("最近結果: " .. tostring(info.last_reason))

    imgui.separator()
    if imgui.button("翻滾取消診斷（輸出到日誌）") then evade_cancel.dump() end

    imgui.tree_pop()
end

local function draw_hellfire_tree()
    if not imgui.tree_node("甩掉鬼火（鐵蟲絲響打）") then return end

    local changed, value

    changed, value = imgui.checkbox("啟用甩鬼火（預設開）", config.get("hellfire_shake_enabled"))
    if changed then config.set("hellfire_shake_enabled", value) end
    imgui.text_colored("動作播到指定幀時，把鬼火留在原地並清掉鬼火やられ", 0.7, 0.7, 0.7, 1.0)
    imgui.text_colored("＝ 用狩獵笛動作做翔蟲動作原本才能做的事", 0.7, 0.7, 0.7, 1.0)

    imgui.separator()
    changed, hellfire_actions_buffer = imgui.input_text("甩鬼火的動作（逗號分隔）", hellfire_actions_buffer)
    if changed then config.set("hellfire_shake_actions", hellfire_actions_buffer) end
    imgui.text_colored("預設：鐵蟲絲響打起手（60 幀）", 0.7, 0.7, 0.7, 1.0)
    imgui.text_colored("演奏收尾不用加 —— 它本來就會甩鬼火（遊戲原生行為）",
        0.65, 0.85, 0.65, 1.0)

    changed, value = imgui.slider_int("甩鬼火的動作幀", config.get("hellfire_shake_frame"), 0, 120)
    if changed then config.set("hellfire_shake_frame", value) end
    if (config.get("hellfire_shake_frame") or 0) >= 60 then
        imgui.text_colored("⚠ 這個動作全長只有 60 幀，設到 60 以上會永遠等不到", 1.0, 0.55, 0.45, 1.0)
    else
        imgui.text_colored("身上沒有鬼火時完全不會動作（不會憑空生出地上鬼火）", 0.7, 0.7, 0.7, 1.0)
    end

    imgui.separator()

    local info = hellfire.get_info()
    if not info.api_ok then
        imgui.text_colored(info.api_tried and "鬼火 API 不可用（請看日誌）" or "鬼火 API 尚未嘗試（進任務後才會初始化）",
            1.0, 0.55, 0.45, 1.0)
    end

    if info.has_hellfire then
        imgui.text_colored("身上有鬼火（鬼火やられ）", 1.0, 0.55, 0.9, 1.0)
    else
        imgui.text_colored("身上沒有鬼火", 0.7, 0.7, 0.7, 1.0)
    end

    imgui.text(string.format("目前 action %d（幀 %.1f）%s", info.action, info.motion_frame,
        info.is_target and "　← 目標動作" or ""))
    if info.is_target then
        if info.done then
            imgui.text_colored("→ 這個動作已處理過（成功或確定沒鬼火）", 0.7, 0.7, 0.7, 1.0)
        elseif info.motion_frame < info.frame then
            imgui.text_colored(string.format("→ 還要 %.0f 幀才到 %d", info.frame - info.motion_frame, info.frame),
                1.0, 0.85, 0.3, 1.0)
        else
            imgui.text_colored("→ 已過觸發幀", 0.4, 1.0, 0.4, 1.0)
        end
    end

    imgui.text(string.format("甩掉 %d 次 / 沒鬼火 %d / 座標失敗 %d / 呼叫失敗 %d",
        info.shakes, info.no_debuff, info.pos_fail, info.fail))
    imgui.text("最近結果: " .. tostring(info.last_reason))

    imgui.separator()
    if imgui.button("手動甩一次鬼火（測試用）") then
        local ok, why = hellfire.shake("手動測試")
        log.info("[HornResonance/hellfire] 手動測試：" .. tostring(why) .. (ok and "（成功）" or "（未執行）"))
    end
    imgui.same_line()
    if imgui.button("甩鬼火診斷（輸出到日誌）") then hellfire.dump() end
    imgui.text_colored("手動按鈕身上沒鬼火時不會有任何效果", 0.7, 0.7, 0.7, 1.0)

    imgui.tree_pop()
end

local function draw_derive_tree()
    if not imgui.tree_node("派生取消點學習") then return end

    local changed, value

    changed, value = imgui.checkbox("A 自動學習（預設關閉）", config.get("derive_learn_enabled"))
    if changed then config.set("derive_learn_enabled", value) end
    imgui.text_colored("正常打就自己學：動作 A 派生到 B 的那一幀 = A 的取消點", 0.7, 0.7, 0.7, 1.0)
    imgui.text_colored("v2.3.10 起預設關閉：內建種子已有 20 個實測取消點，", 0.85, 0.8, 0.5, 1.0)
    imgui.text_colored("打開後你自己的派生會覆蓋內建值（可能反而更差），需要再開。",
        0.85, 0.8, 0.5, 1.0)

    changed, value = imgui.checkbox("B 收集模式（每次觀測都寫日誌）", config.get("derive_collect_enabled"))
    if changed then config.set("derive_collect_enabled", value) end
    imgui.text_colored("日誌會出現 [LEARN] / [LEARN-REJECT] / [LEN]，可整段貼出來檢查",
        0.7, 0.7, 0.7, 1.0)

    imgui.separator()

    local a = game.get_action_id()
    local entry = derive.get_derive_entry(a)
    local len = derive.get_length(a)

    imgui.text(string.format("目前 action %d / bank %d", a, game.get_bank_id()))
    if entry then
        local src = (entry.hits == 0) and "內建種子" or string.format("看過 %d 次", entry.hits)
        imgui.text(string.format("  派生點 %.0f 幀（→ %d，%s）", entry.frame, entry.to, src))
    else
        imgui.text("  派生點：尚未學到")
    end
    imgui.text("  動作總長: " .. (len and string.format("%.0f 幀", len) or "尚未學到"))
    imgui.text(string.format("目前幀數: %.1f", game.get_motion_frame()))

    imgui.separator()
    imgui.text(string.format("已學習：派生點 %d 個動作 / 動作長度 %d 個動作",
        derive.count(), derive.length_count()))
    imgui.text_colored("內建種子已預先包含實測過的取消點，新用戶不用重學", 0.7, 0.7, 0.7, 1.0)

    local s = derive.stats()
    imgui.text(string.format("觀測 %d / 採用 %d", s.observations, s.accepted))
    imgui.text(string.format("否決：自己跳 %d、來源非攻擊 %d、目標非攻擊 %d",
        s.reject_self, s.reject_from, s.reject_to))
    imgui.text(string.format("　　　沒按鍵 %d、太前面 %d、同動作 %d",
        s.reject_input, s.reject_early, s.reject_same))

    imgui.separator()
    if imgui.button("輸出學習表到日誌") then derive.dump() end
    imgui.same_line()
    if imgui.button("清空個人學習資料") then derive.reset() end
    imgui.text_colored("清空只會清掉自己玩的紀錄，內建種子會保留", 0.7, 0.7, 0.7, 1.0)

    imgui.text_colored("資料存在 reframework/data/horn_resonance_derive.json", 0.7, 0.7, 0.7, 1.0)

    imgui.tree_pop()
end

function settings.on_draw_ui()

    if not imgui.tree_node("狩獵笛：L2 接技氣焰旋律") then return end

    local changed, value
    changed, value = imgui.checkbox("啟用 (Enable)", config.get("enabled"))
    if changed then config.set("enabled", value) end

    changed, value = imgui.checkbox("詳細日誌", config.get("log_verbose"))
    if changed then config.set("log_verbose", value) end

    imgui.text_colored("ZL+A 的共鳴音珠維持原樣，沒有被改動", 0.7, 0.7, 0.7, 1.0)

    imgui.separator()

    draw_combo_tree()
    draw_rules_tree()
    draw_iframe_tree()
    draw_evade_cancel_tree()
    draw_hellfire_tree()
    draw_derive_tree()

    if imgui.tree_node("診斷") then
        if imgui.button("開啟識別碼記錄器") then recorder_open = true end
        imgui.tree_pop()
    end

    imgui.tree_pop()
end

function settings.on_frame()
    refresh_buffers()

    if not recorder_open then return end

    recorder_open = imgui.begin_window("HornResonance 識別碼記錄器", recorder_open, 0)
    if not recorder_open then return end

    imgui.text("即時數值")
    imgui.separator()
    imgui.text("武器類型: " .. tostring(game.get_weapon_type()) .. "  (狩獵笛 = 10)")
    imgui.text("Action Bank: " .. tostring(game.get_bank_id()))
    imgui.text("Action ID  : " .. tostring(game.get_action_id()))
    imgui.text(string.format("目前識別碼 : 0x%08X", game.get_current_node() or 0))
    imgui.text(string.format("動作幀數   : %.1f", game.get_frame() or 0.0))
    imgui.text("攻擊中     : " .. tostring(game.is_attack()))

    local d = derive.get_derive(game.get_action_id())
    imgui.text("本動作派生點: " .. (d and string.format("%.0f 幀", d) or "尚未學到"))

    imgui.separator()
    imgui.text("使用步驟：")
    imgui.text("1. 用三音演奏→ZR 使出氣焰旋律，動作進行中按下面按鈕記錄識別碼")
    imgui.text("2. 一般攻擊中輕點 L2，就會接上氣焰旋律")

    imgui.separator()
    if imgui.button("記錄為【氣焰旋律】") then capture_infernal() end

    imgui.separator()
    local changed
    changed, infernal_hex_buffer = imgui.input_text("氣焰旋律 識別碼（進階，遊戲改版後才需調整）", infernal_hex_buffer)
    if changed then apply_infernal_hex(infernal_hex_buffer) end

    imgui.separator()
    if imgui.button("測試：立刻跳到氣焰旋律") then
        local node = config.get("infernal_node")
        if node and node ~= 0 then
            game.set_current_node(node)
        else
            log.warn("[HornResonance] 尚未設定氣焰旋律節點")
        end
    end

    imgui.end_window()
end

return settings
