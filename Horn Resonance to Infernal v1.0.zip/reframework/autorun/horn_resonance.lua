local game = require("horn_resonance/core/game")
local resonance_manager = require("horn_resonance/core/resonance_manager")
local hooks = require("horn_resonance/core/hooks")
local settings = require("horn_resonance/ui/settings")

local was_ready = false

re.on_pre_application_entry("UpdateScene", function()
    game.refresh_world()

    local ready = game.is_ready()

    if was_ready and not ready then
        resonance_manager.reset()
    end
    was_ready = ready

    if game.is_horn() then
        hooks:enable_hooks()
    else
        hooks:disable_hooks()
    end
end)

re.on_frame(function()
    settings.on_frame()
end)

re.on_draw_ui(function()
    settings.on_draw_ui()
end)
